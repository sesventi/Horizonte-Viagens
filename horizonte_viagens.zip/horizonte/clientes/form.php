<?php
require_once __DIR__ . '/../includes/init.php';

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$c = ['nome' => '', 'cpf' => '', 'telefone' => '', 'email' => '', 'endereco' => ''];
if ($id) {
    $s = db()->prepare('SELECT * FROM clientes WHERE id = ?'); $s->execute([$id]);
    $c = $s->fetch();
    if (!$c) { flash('error', 'Cliente não encontrado.'); redirect('clientes/index.php'); }
}

$erros = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $c = ['nome' => post('nome'), 'cpf' => so_digitos(post('cpf')), 'telefone' => post('telefone'),
          'email' => mb_strtolower(post('email')), 'endereco' => post('endereco')];

    if (mb_strlen($c['nome']) < 5 || !str_contains($c['nome'], ' ')) $erros['nome'] = 'Informe o nome completo.';
    if (!cpf_valido($c['cpf']))                                        $erros['cpf'] = 'CPF inválido.';
    $tel = so_digitos($c['telefone']);
    if (strlen($tel) < 10 || strlen($tel) > 11)                        $erros['telefone'] = 'Telefone inválido. Use DDD + número.';
    if (!filter_var($c['email'], FILTER_VALIDATE_EMAIL))               $erros['email'] = 'E-mail inválido.';
    if (mb_strlen($c['endereco']) < 8)                                 $erros['endereco'] = 'Informe o endereço completo.';

    if (!$erros) {   // CPF e e-mail não podem se repetir
        $s = db()->prepare('SELECT cpf, email FROM clientes WHERE (cpf = ? OR email = ?) AND id <> ?');
        $s->execute([$c['cpf'], $c['email'], $id]);
        foreach ($s->fetchAll() as $dup) {
            if ($dup['cpf'] === $c['cpf'])     $erros['cpf'] = 'Já existe um cliente com este CPF.';
            if ($dup['email'] === $c['email']) $erros['email'] = 'Já existe um cliente com este e-mail.';
        }
    }
    if (!$erros) {
        try {
            if ($id) {
                db()->prepare('UPDATE clientes SET nome=?, cpf=?, telefone=?, email=?, endereco=? WHERE id=?')
                    ->execute([$c['nome'], $c['cpf'], $c['telefone'], $c['email'], $c['endereco'], $id]);
                registrar_historico('editou', 'clientes', $id, 'Cliente "' . $c['nome'] . '" atualizado');
                flash('success', 'Cliente atualizado com sucesso.');
            } else {
                db()->prepare('INSERT INTO clientes (nome, cpf, telefone, email, endereco) VALUES (?,?,?,?,?)')
                    ->execute([$c['nome'], $c['cpf'], $c['telefone'], $c['email'], $c['endereco']]);
                registrar_historico('criou', 'clientes', (int)db()->lastInsertId(), 'Cliente "' . $c['nome'] . '" cadastrado');
                flash('success', 'Cliente cadastrado com sucesso.');
            }
            redirect('clientes/index.php');
        } catch (PDOException $ex) {
            $erros['geral'] = 'Não foi possível salvar o cliente. Tente novamente.';
        }
    }
}

$titulo = $id ? 'Editar cliente' : 'Novo cliente'; $menu = 'clientes';
require __DIR__ . '/../includes/header.php';
$campo = function (string $nome, string $rotulo, string $extra = '', string $tipo = 'text') use ($c, $erros) {
    $inv = isset($erros[$nome]) ? ' invalid' : '';
    echo '<label class="field' . $inv . '"><span>' . $rotulo . '</span><input type="' . $tipo . '" name="' . $nome . '" value="' . e($c[$nome]) . '" ' . $extra . ' required>'
       . (isset($erros[$nome]) ? '<span class="err">' . e($erros[$nome]) . '</span>' : '') . '</label>';
};
?>
<div class="page-head"><div><h2><?= e($titulo) ?></h2><p>Todos os campos são obrigatórios.</p></div>
  <a class="btn btn-ghost" href="<?= url('clientes/index.php') ?>">Voltar</a></div>

<form method="post" class="card form-card" data-validate>
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
  <?php if (isset($erros['geral'])): ?><div class="alert alert-error"><?= icon('alert', 18) ?><span><?= e($erros['geral']) ?></span></div><?php endif; ?>
  <div class="form-grid">
    <div class="full"><?php $campo('nome', 'Nome completo', 'maxlength="120" autocomplete="off"'); ?></div>
    <?php $campo('cpf', 'CPF', 'data-mask="cpf" inputmode="numeric" placeholder="000.000.000-00"'); ?>
    <?php $campo('telefone', 'Telefone', 'data-mask="tel" inputmode="tel" placeholder="(11) 90000-0000"'); ?>
    <div class="full"><?php $campo('email', 'E-mail', 'maxlength="120"', 'email'); ?></div>
    <div class="full"><?php $campo('endereco', 'Endereço', 'maxlength="255" placeholder="Rua, número, bairro, cidade/UF"'); ?></div>
  </div>
  <div class="form-actions"><a class="btn btn-ghost" href="<?= url('clientes/index.php') ?>">Cancelar</a>
    <button class="btn btn-primary" type="submit"><?= $id ? 'Salvar alterações' : 'Cadastrar cliente' ?></button></div>
</form>
<?php require __DIR__ . '/../includes/footer.php'; ?>
