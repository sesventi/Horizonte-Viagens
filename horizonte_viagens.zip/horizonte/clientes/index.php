<?php
require_once __DIR__ . '/../includes/init.php';

/* Pesquisa dinâmica + filtro por período de cadastro + paginação */
$q = get('q'); $de = get('de'); $ate = get('ate');
$where = ['1=1']; $params = [];
if ($q !== '') {
    $where[] = '(c.nome LIKE ? OR c.cpf LIKE ? OR c.email LIKE ? OR c.telefone LIKE ?)';
    $like = '%' . $q . '%'; $dig = '%' . so_digitos($q) . '%';
    array_push($params, $like, so_digitos($q) !== '' ? $dig : $like, $like, $like);
}
if ($de  !== '' && data_valida($de))  { $where[] = 'DATE(c.criado_em) >= ?'; $params[] = $de; }
if ($ate !== '' && data_valida($ate)) { $where[] = 'DATE(c.criado_em) <= ?'; $params[] = $ate; }
$sqlWhere = implode(' AND ', $where);

$s = db()->prepare("SELECT COUNT(*) FROM clientes c WHERE $sqlWhere");
$s->execute($params);
$pg = paginar((int)$s->fetchColumn());

$s = db()->prepare("SELECT c.*, (SELECT COUNT(*) FROM reservas r WHERE r.cliente_id = c.id AND r.status <> 'cancelada') AS reservas
                      FROM clientes c WHERE $sqlWhere ORDER BY c.nome LIMIT {$pg['limite']} OFFSET {$pg['offset']}");
$s->execute($params);
$clientes = $s->fetchAll();

$titulo = 'Clientes'; $menu = 'clientes';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <div><h2>Clientes</h2><p>Consulte e mantenha o cadastro de clientes da agência.</p></div>
  <a class="btn btn-primary" href="<?= url('clientes/form.php') ?>"><?= icon('plus', 18) ?> Novo cliente</a>
</div>

<div class="card">
  <form class="filters" data-live method="get" action="<?= url('clientes/index.php') ?>">
    <label class="field grow search"><span>Pesquisar</span><?= icon('search', 18) ?>
      <input type="search" name="q" value="<?= e($q) ?>" placeholder="Nome, CPF, e-mail ou telefone" style="margin-top:0"></label>
    <label class="field"><span>Cadastrado de</span><input type="date" name="de" value="<?= e($de) ?>"></label>
    <label class="field"><span>até</span><input type="date" name="ate" value="<?= e($ate) ?>"></label>
  </form>

  <div id="lista">
    <?php if (!$clientes): ?>
      <div class="empty"><strong>Nenhum cliente encontrado</strong>Ajuste a pesquisa ou cadastre um novo cliente.</div>
    <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Cliente</th><th>CPF</th><th>Telefone</th><th>Endereço</th><th class="num">Reservas</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($clientes as $c): ?>
        <tr>
          <td><div class="cell-user"><span class="avatar"><?= e(iniciais($c['nome'])) ?></span><div><strong><?= e($c['nome']) ?></strong><small><?= e($c['email']) ?></small></div></div></td>
          <td><?= e(fmt_cpf($c['cpf'])) ?></td>
          <td><?= e($c['telefone']) ?></td>
          <td><?= e($c['endereco']) ?></td>
          <td class="num"><?= (int)$c['reservas'] ?></td>
          <td><div class="row-actions">
            <a class="icon-btn" title="Editar" href="<?= url('clientes/form.php?id=' . $c['id']) ?>"><?= icon('edit', 18) ?></a>
            <form method="post" action="<?= url('clientes/excluir.php') ?>" data-confirm="O cliente <?= e($c['nome']) ?> será removido permanentemente. Deseja continuar?">
              <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="icon-btn danger" title="Excluir" type="submit"><?= icon('trash', 18) ?></button>
            </form>
          </div></td>
        </tr>
      <?php endforeach; ?>
      </tbody></table></div>
    <?php endif; ?>
    <?= paginacao_html($pg) ?>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
