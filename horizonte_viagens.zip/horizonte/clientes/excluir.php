<?php
require_once __DIR__ . '/../includes/init.php';
exigir_post();
$id = (int)($_POST['id'] ?? 0);

$s = db()->prepare('SELECT nome FROM clientes WHERE id = ?'); $s->execute([$id]);
$nome = $s->fetchColumn();
if ($nome === false) { flash('error', 'Cliente não encontrado.'); redirect('clientes/index.php'); }

$s = db()->prepare('SELECT COUNT(*) FROM reservas WHERE cliente_id = ?'); $s->execute([$id]);
if ((int)$s->fetchColumn() > 0) {
    flash('error', 'Não é possível excluir "' . $nome . '": o cliente possui reservas vinculadas.');
    redirect('clientes/index.php');
}
try {
    db()->prepare('DELETE FROM clientes WHERE id = ?')->execute([$id]);
    registrar_historico('excluiu', 'clientes', $id, 'Cliente "' . $nome . '" excluído');
    flash('success', 'Cliente excluído com sucesso.');
} catch (PDOException $e) {
    flash('error', 'Não foi possível excluir o cliente.');
}
redirect('clientes/index.php');
