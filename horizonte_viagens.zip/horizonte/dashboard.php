<?php
require_once __DIR__ . '/includes/init.php';
$pdo = db();

/* ----- Filtro de período (aplicado a reservas e pagamentos) ----- */
$de  = get('de');  if ($de  !== '' && !data_valida($de))  $de  = '';
$ate = get('ate'); if ($ate !== '' && !data_valida($ate)) $ate = '';

$wRes = ['1=1']; $pRes = [];
$wPag = ['1=1']; $pPag = [];
if ($de  !== '') { $wRes[] = 'DATE(r.criado_em) >= ?';    $pRes[] = $de;  $wPag[] = 'p.data_pagamento >= ?'; $pPag[] = $de; }
if ($ate !== '') { $wRes[] = 'DATE(r.criado_em) <= ?';    $pRes[] = $ate; $wPag[] = 'p.data_pagamento <= ?'; $pPag[] = $ate; }
$sqlRes = implode(' AND ', $wRes);
$sqlPag = implode(' AND ', $wPag);

function consulta(string $sql, array $params = []): array
{
    $s = db()->prepare($sql);
    $s->execute($params);
    return $s->fetchAll();
}
function escalar(string $sql, array $params = [])
{
    $s = db()->prepare($sql);
    $s->execute($params);
    return $s->fetchColumn();
}

/* ----- Indicadores ----- */
$totClientes   = (int)escalar('SELECT COUNT(*) FROM clientes');
$pacotesDisp   = (int)escalar("SELECT COUNT(*) FROM vw_pacotes WHERE ativo = 1 AND data_saida >= CURDATE() AND vagas_disponiveis > 0");
$rr = consulta("SELECT COUNT(*) total, COALESCE(SUM(r.status = 'cancelada'), 0) canc FROM reservas r WHERE $sqlRes", $pRes)[0];
$reservasAtivas = (int)$rr['total'] - (int)$rr['canc'];
$recebido      = (float)escalar("SELECT COALESCE(SUM(p.valor), 0) FROM pagamentos p WHERE $sqlPag", $pPag);
$aReceber      = (float)escalar("SELECT COALESCE(SUM(r.valor_total - r.valor_pago), 0) FROM reservas r WHERE r.status <> 'cancelada' AND r.status_pagamento <> 'pago' AND $sqlRes", $pRes);
$qtdPendentes  = (int)escalar("SELECT COUNT(*) FROM reservas r WHERE r.status <> 'cancelada' AND r.status_pagamento <> 'pago' AND $sqlRes", $pRes);

/* ----- Série mensal (reservas e receita) ----- */
$mesesPt = ['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
$ini = $de  ? new DateTime(substr($de, 0, 7) . '-01')  : (new DateTime('first day of this month'))->modify('-8 months');
$fim = $ate ? new DateTime(substr($ate, 0, 7) . '-01') : new DateTime('first day of this month');
if ($ini > $fim) $ini = clone $fim;
if ($ini < (clone $fim)->modify('-23 months')) $ini = (clone $fim)->modify('-23 months');
$limiteSup = (clone $fim)->modify('+1 month')->format('Y-m-d');

$resMes = array_column(consulta("SELECT DATE_FORMAT(criado_em,'%Y-%m') ym, COUNT(*) n FROM reservas
    WHERE status <> 'cancelada' AND criado_em >= ? AND criado_em < ? GROUP BY ym", [$ini->format('Y-m-d'), $limiteSup]), 'n', 'ym');
$recMes = array_column(consulta("SELECT DATE_FORMAT(data_pagamento,'%Y-%m') ym, SUM(valor) v FROM pagamentos
    WHERE data_pagamento >= ? AND data_pagamento < ? GROUP BY ym", [$ini->format('Y-m-d'), $limiteSup]), 'v', 'ym');

$labels = $serieRes = $serieRec = [];
for ($d = clone $ini; $d <= $fim; $d->modify('+1 month')) {
    $k = $d->format('Y-m');
    $labels[]   = $mesesPt[(int)$d->format('n') - 1] . '/' . $d->format('y');
    $serieRes[] = (int)($resMes[$k] ?? 0);
    $serieRec[] = (float)($recMes[$k] ?? 0);
}

/* ----- Rosca: situação financeira e destinos ----- */
$sit = array_column(consulta("SELECT r.status_pagamento s, COUNT(*) n FROM reservas r WHERE r.status <> 'cancelada' AND $sqlRes GROUP BY r.status_pagamento", $pRes), 'n', 's');
$destinos = consulta("SELECT d.cidade, COUNT(*) n FROM reservas r JOIN pacotes pk ON pk.id = r.pacote_id JOIN destinos d ON d.id = pk.destino_id
    WHERE r.status <> 'cancelada' AND $sqlRes GROUP BY d.id, d.cidade ORDER BY n DESC LIMIT 5", $pRes);

/* ----- Listas ----- */
$topClientes = consulta("SELECT c.nome, c.email, COUNT(*) reservas, SUM(r.valor_total) total FROM reservas r JOIN clientes c ON c.id = r.cliente_id
    WHERE r.status <> 'cancelada' AND $sqlRes GROUP BY c.id, c.nome, c.email ORDER BY total DESC LIMIT 5", $pRes);
$proximas = consulta("SELECT id, titulo, cidade, data_saida, vagas_total, vagas_ocupadas, vagas_disponiveis FROM vw_pacotes
    WHERE ativo = 1 AND data_saida >= CURDATE() ORDER BY data_saida LIMIT 5");
$pendencias = consulta("SELECT r.id, c.nome, pk.titulo, r.valor_total, r.valor_pago, r.status_pagamento FROM reservas r
    JOIN clientes c ON c.id = r.cliente_id JOIN pacotes pk ON pk.id = r.pacote_id
    WHERE r.status <> 'cancelada' AND r.status_pagamento <> 'pago' AND $sqlRes ORDER BY (r.valor_total - r.valor_pago) DESC LIMIT 6", $pRes);

$titulo = 'Dashboard'; $menu = 'dashboard'; $scripts = ['charts.js'];
require __DIR__ . '/includes/header.php';
$primeiroNome = explode(' ', $_SESSION['usuario']['nome'])[0];
?>
<div class="page-head">
  <div><h2>Olá, <?= e($primeiroNome) ?></h2><p>Resumo da agência<?= ($de || $ate) ? ' no período selecionado' : '' ?>.</p></div>
  <form method="get" class="filters" style="margin:0">
    <label class="field"><span>De</span><input type="date" name="de" value="<?= e($de) ?>"></label>
    <label class="field"><span>Até</span><input type="date" name="ate" value="<?= e($ate) ?>"></label>
    <button class="btn btn-primary" type="submit"><?= icon('filter', 16) ?> Filtrar</button>
    <?php if ($de || $ate): ?><a class="btn btn-ghost" href="<?= url('dashboard.php') ?>">Limpar</a><?php endif; ?>
  </form>
</div>

<section class="kpis">
  <a class="card kpi" href="<?= url('clientes/index.php') ?>"><span class="ico"><?= icon('users', 22) ?></span><div><small>Clientes cadastrados</small><strong><?= $totClientes ?></strong></div></a>
  <a class="card kpi ocean" href="<?= url('pacotes/index.php?situacao=disponivel') ?>"><span class="ico"><?= icon('package', 22) ?></span><div><small>Viagens disponíveis</small><strong><?= $pacotesDisp ?></strong></div></a>
  <a class="card kpi sun" href="<?= url('reservas/index.php') ?>"><span class="ico"><?= icon('calendar', 22) ?></span><div><small>Reservas realizadas</small><strong><?= $reservasAtivas ?></strong><span class="sub"><?= (int)$rr['canc'] ?> cancelada(s)</span></div></a>
  <a class="card kpi green" href="<?= url('pagamentos/index.php') ?>"><span class="ico"><?= icon('trend', 22) ?></span><div><small>Pagamentos confirmados</small><strong><?= brl($recebido) ?></strong></div></a>
  <a class="card kpi coral" href="<?= url('reservas/index.php?situacao_pg=pendente') ?>"><span class="ico"><?= icon('wallet', 22) ?></span><div><small>Pagamentos pendentes</small><strong><?= brl($aReceber) ?></strong><span class="sub"><?= $qtdPendentes ?> reserva(s) em aberto</span></div></a>
</section>

<section class="grid-3">
  <div class="card"><div class="card-head"><h3>Reservas por mês</h3></div>
    <div class="chart" data-type="bar" data-format="int" data-title="Reservas por mês" data-labels='<?= e(json_encode($labels)) ?>' data-values='<?= e(json_encode($serieRes)) ?>'></div></div>
  <div class="card"><div class="card-head"><h3>Situação financeira</h3></div>
    <div class="chart" data-type="donut" data-center="reservas" data-title="Reservas por situação financeira"
         data-labels='["Pagas","Parciais","Pendentes"]' data-values='<?= e(json_encode([(int)($sit['pago'] ?? 0), (int)($sit['parcial'] ?? 0), (int)($sit['pendente'] ?? 0)])) ?>'
         data-colors='["#1FA37A","#0E8FA0","#F2994A"]'></div></div>
</section>

<section class="grid-3">
  <div class="card"><div class="card-head"><h3>Receita recebida por mês</h3></div>
    <div class="chart" data-type="bar" data-format="money" data-color="#F2994A" data-title="Receita por mês" data-labels='<?= e(json_encode($labels)) ?>' data-values='<?= e(json_encode($serieRec)) ?>'></div></div>
  <div class="card"><div class="card-head"><h3>Reservas por destino</h3></div>
    <div class="chart" data-type="donut" data-center="reservas" data-title="Reservas por destino"
         data-labels='<?= e(json_encode(array_column($destinos, 'cidade'))) ?>' data-values='<?= e(json_encode(array_map('intval', array_column($destinos, 'n')))) ?>'></div></div>
</section>

<section class="grid-2">
  <div class="card"><div class="card-head"><h3>Melhores clientes</h3><a href="<?= url('clientes/index.php') ?>" class="btn btn-ghost btn-sm">Ver todos</a></div>
    <?php if (!$topClientes): ?><div class="empty">Nenhuma reserva no período.</div><?php else: ?>
    <ul class="rank"><?php foreach ($topClientes as $c): ?>
      <li><span class="avatar"><?= e(iniciais($c['nome'])) ?></span>
        <div class="grow"><strong><?= e($c['nome']) ?></strong><small><?= e($c['email']) ?></small></div>
        <div style="text-align:right"><strong><?= brl($c['total']) ?></strong><br><small class="muted"><?= (int)$c['reservas'] ?> reserva(s)</small></div></li>
    <?php endforeach; ?></ul><?php endif; ?></div>

  <div class="card"><div class="card-head"><h3>Próximas saídas</h3><a href="<?= url('pacotes/index.php') ?>" class="btn btn-ghost btn-sm">Ver pacotes</a></div>
    <?php if (!$proximas): ?><div class="empty">Nenhum pacote disponível.</div><?php else: ?>
    <ul class="rank"><?php foreach ($proximas as $p): $pct = $p['vagas_total'] ? round($p['vagas_ocupadas'] * 100 / $p['vagas_total']) : 0; ?>
      <li><div class="grow"><strong><?= e($p['titulo']) ?></strong><small><?= e($p['cidade']) ?> &middot; saída em <?= data_br($p['data_saida']) ?></small>
        <div class="progress <?= $p['vagas_disponiveis'] <= 0 ? 'full' : '' ?>"><i style="width:<?= $pct ?>%"></i></div></div>
        <div style="text-align:right"><strong><?= (int)$p['vagas_disponiveis'] ?></strong><br><small class="muted">vaga(s)</small></div></li>
    <?php endforeach; ?></ul><?php endif; ?></div>
</section>

<section class="card" style="margin-top:18px">
  <div class="card-head"><h3>Pagamentos pendentes por reserva</h3><a href="<?= url('pagamentos/form.php') ?>" class="btn btn-primary btn-sm"><?= icon('plus', 16) ?> Registrar pagamento</a></div>
  <?php if (!$pendencias): ?><div class="empty"><strong>Tudo em dia!</strong>Nenhuma reserva com saldo em aberto.</div><?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Reserva</th><th>Cliente</th><th>Pacote</th><th class="num">Total</th><th class="num">Pago</th><th class="num">Saldo</th><th>Situação</th></tr></thead>
    <tbody><?php foreach ($pendencias as $r): ?>
      <tr><td>#<?= (int)$r['id'] ?></td><td><?= e($r['nome']) ?></td><td><?= e($r['titulo']) ?></td>
        <td class="num"><?= brl($r['valor_total']) ?></td><td class="num"><?= brl($r['valor_pago']) ?></td>
        <td class="num"><strong><?= brl($r['valor_total'] - $r['valor_pago']) ?></strong></td><td><?= badge($r['status_pagamento']) ?></td></tr>
    <?php endforeach; ?></tbody></table></div><?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
