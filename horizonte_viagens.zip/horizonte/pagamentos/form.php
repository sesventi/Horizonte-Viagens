<?php
require_once __DIR__ . '/../includes/init.php';
$pdo = db();
$formas = formas_pagamento();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$p = ['reserva_id' => (int)($_GET['reserva_id'] ?? 0), 'valor' => '', 'data_pagamento' => date('Y-m-d'), 'forma' => 'pix', 'observacao' => ''];
$orig = null;
if ($id) {
    $s = $pdo->prepare('SELECT * FROM pagamentos WHERE id = ?'); $s->execute([$id]);
    $p = $s->fetch();
    if (!$p) { flash('error', 'Pagamento não encontrado.'); redirect('pagamentos/index.php'); }
    $orig = $p;
}

$erros = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $p = ['reserva_id' => (int)post('reserva_id'), 'valor' => str_replace(',', '.', post('valor')), 'data_pagamento' => post('data_pagamento'),
          'forma' => post('forma'), 'observacao' => post('observacao')];

    if (!is_numeric($p['valor']) || (float)$p['valor'] <= 0) $erros['valor'] = 'Informe um valor maior que zero.';
    if (!data_valida($p['data_pagamento']))                  $erros['data_pagamento'] = 'Data inválida.';
    elseif ($p['data_pagamento'] > date('Y-m-d'))            $erros['data_pagamento'] = 'A data do pagamento não pode ser futura.';
    if (!isset($formas[$p['forma']]))                        $erros['forma'] = 'Escolha a forma de pagamento.';
    if (mb_strlen($p['observacao']) > 255)                   $erros['observacao'] = 'Máximo de 255 caracteres.';

    if (!$erros) {
        try {
            $pdo->beginTransaction();
            $s = $pdo->prepare('SELECT valor_total, status FROM reservas WHERE id = ? FOR UPDATE');
            $s->execute([$p['reserva_id']]);
            $res = $s->fetch();
            if (!$res) throw new RuntimeException('reserva_id|Selecione uma reserva.');
            if ($res['status'] === 'cancelada') throw new RuntimeException('reserva_id|Esta reserva está cancelada e não aceita pagamentos.');

            $s = $pdo->prepare('SELECT COALESCE(SUM(valor), 0) FROM pagamentos WHERE reserva_id = ? AND id <> ?');
            $s->execute([$p['reserva_id'], $id]);
            $saldo = round((float)$res['valor_total'] - (float)$s->fetchColumn(), 2);
            $valor = round((float)$p['valor'], 2);
            if ($valor > $saldo) throw new RuntimeException('valor|O valor excede o saldo da reserva (' . brl($saldo) . ').');

            if ($id) {
                $pdo->prepare('UPDATE pagamentos SET reserva_id=?, valor=?, data_pagamento=?, forma=?, observacao=? WHERE id=?')
                    ->execute([$p['reserva_id'], $valor, $p['data_pagamento'], $p['forma'], $p['observacao'] ?: null, $id]);
                $pid = $id;
                if ((int)$orig['reserva_id'] !== $p['reserva_id']) atualizar_financeiro((int)$orig['reserva_id']);
            } else {
                $pdo->prepare('INSERT INTO pagamentos (reserva_id, valor, data_pagamento, forma, observacao) VALUES (?,?,?,?,?)')
                    ->execute([$p['reserva_id'], $valor, $p['data_pagamento'], $p['forma'], $p['observacao'] ?: null]);
                $pid = (int)$pdo->lastInsertId();
            }
            atualizar_financeiro($p['reserva_id']);
            registrar_historico($id ? 'editou' : 'criou', 'pagamentos', $pid, 'Pagamento de ' . brl($valor) . ' (' . $formas[$p['forma']] . ') na reserva #' . $p['reserva_id']);
            $pdo->commit();
            flash('success', $id ? 'Pagamento atualizado. Situação financeira recalculada.' : 'Pagamento registrado. Situação financeira da reserva atualizada.');
            redirect('pagamentos/index.php');
        } catch (RuntimeException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            [$campo, $msg] = array_pad(explode('|', $ex->getMessage(), 2), 2, '');
            $erros[$campo ?: 'geral'] = $msg ?: 'Erro ao salvar.';
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $erros['geral'] = 'Não foi possível salvar o pagamento.';
        }
    }
}

// Reservas que aceitam pagamento (com saldo) + a reserva do pagamento em edição
$s = $pdo->prepare("SELECT r.id, r.valor_total, r.valor_pago, c.nome, pk.titulo FROM reservas r
    JOIN clientes c ON c.id = r.cliente_id JOIN pacotes pk ON pk.id = r.pacote_id
    WHERE (r.status <> 'cancelada' AND r.valor_total > r.valor_pago) OR r.id = ? ORDER BY r.id DESC");
$s->execute([(int)($orig['reserva_id'] ?? 0)]);
$reservas = $s->fetchAll();

$titulo = $id ? 'Editar pagamento' : 'Registrar pagamento'; $menu = 'pagamentos';
require __DIR__ . '/../includes/header.php';
$err = fn(string $c) => isset($erros[$c]) ? '<span class="err">' . e($erros[$c]) . '</span>' : '';
$inv = fn(string $c) => isset($erros[$c]) ? ' invalid' : '';
?>
<div class="page-head"><div><h2><?= e($titulo) ?></h2><p>Informe valor, data e forma de pagamento da reserva.</p></div>
  <a class="btn btn-ghost" href="<?= url('pagamentos/index.php') ?>">Voltar</a></div>

<?php if (!$reservas): ?>
  <div class="card empty"><strong>Nenhuma reserva com saldo em aberto</strong>Registre uma reserva antes de lançar pagamentos.</div>
<?php else: ?>
<form method="post" class="card form-card" data-validate>
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
  <?php if (isset($erros['geral'])): ?><div class="alert alert-error"><?= icon('alert', 18) ?><span><?= e($erros['geral']) ?></span></div><?php endif; ?>
  <div class="form-grid">
    <label class="field<?= $inv('reserva_id') ?> full"><span>Reserva</span><select name="reserva_id" id="reserva_id" required><option value="">Selecione...</option>
      <?php foreach ($reservas as $r):
        $pagoSemEste = (float)$r['valor_pago'] - ($orig && (int)$orig['reserva_id'] === (int)$r['id'] ? (float)$orig['valor'] : 0);
        $saldo = (float)$r['valor_total'] - $pagoSemEste; ?>
        <option value="<?= (int)$r['id'] ?>" data-total="<?= e($r['valor_total']) ?>" data-pago="<?= e($pagoSemEste) ?>" data-saldo="<?= e(round($saldo, 2)) ?>"
          <?= (int)$p['reserva_id'] === (int)$r['id'] ? 'selected' : '' ?>>#<?= (int)$r['id'] ?> - <?= e($r['nome']) ?> - <?= e($r['titulo']) ?> (saldo <?= e(brl($saldo)) ?>)</option><?php endforeach; ?></select><?= $err('reserva_id') ?></label>
    <div class="full resumo" id="resumoSaldo" hidden>
      <div><small>Valor total</small><strong id="spTotal">-</strong></div>
      <div><small>Já pago</small><strong id="spPago">-</strong></div>
      <div><small>Saldo</small><strong id="spSaldo">-</strong></div>
    </div>
    <label class="field<?= $inv('valor') ?>"><span>Valor (R$)</span><input type="number" id="valor" name="valor" step="0.01" min="0.01" value="<?= e($p['valor']) ?>" required><?= $err('valor') ?>
      <button type="button" class="btn btn-ghost btn-sm" id="btnQuitar" style="align-self:flex-start;margin-top:4px">Preencher com o saldo total</button></label>
    <label class="field<?= $inv('data_pagamento') ?>"><span>Data do pagamento</span><input type="date" name="data_pagamento" max="<?= date('Y-m-d') ?>" value="<?= e($p['data_pagamento']) ?>" required><?= $err('data_pagamento') ?></label>
    <label class="field<?= $inv('forma') ?>"><span>Forma de pagamento</span><select name="forma" required>
      <?php foreach ($formas as $k => $rot): ?><option value="<?= $k ?>" <?= $p['forma'] === $k ? 'selected' : '' ?>><?= e($rot) ?></option><?php endforeach; ?></select><?= $err('forma') ?></label>
    <label class="field<?= $inv('observacao') ?>"><span>Observação (opcional)</span><input name="observacao" maxlength="255" value="<?= e($p['observacao']) ?>" placeholder="Ex.: parcela 1/3"><?= $err('observacao') ?></label>
  </div>
  <div class="form-actions"><a class="btn btn-ghost" href="<?= url('pagamentos/index.php') ?>">Cancelar</a>
    <button class="btn btn-primary" type="submit"><?= $id ? 'Salvar alterações' : 'Registrar pagamento' ?></button></div>
</form>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
