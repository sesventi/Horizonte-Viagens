<?php
require_once __DIR__ . '/../includes/init.php';
exigir_post();
$id = (int)($_POST['id'] ?? 0);

$s = db()->prepare('SELECT reserva_id, valor FROM pagamentos WHERE id = ?'); $s->execute([$id]);
$p = $s->fetch();
if (!$p) { flash('error', 'Pagamento não encontrado.'); redirect('pagamentos/index.php'); }

try {
    db()->beginTransaction();
    db()->prepare('DELETE FROM pagamentos WHERE id = ?')->execute([$id]);
    atualizar_financeiro((int)$p['reserva_id']);
    registrar_historico('excluiu', 'pagamentos', $id, 'Pagamento de ' . brl($p['valor']) . ' da reserva #' . $p['reserva_id'] . ' excluído');
    db()->commit();
    flash('success', 'Pagamento excluído. Situação financeira da reserva recalculada.');
} catch (PDOException $e) {
    if (db()->inTransaction()) db()->rollBack();
    flash('error', 'Não foi possível excluir o pagamento.');
}
redirect('pagamentos/index.php');
