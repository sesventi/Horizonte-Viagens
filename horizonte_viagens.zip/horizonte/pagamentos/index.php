<?php
require_once __DIR__ . '/../includes/init.php';

$q = get('q'); $forma = get('forma'); $sp = get('situacao_pg'); $de = get('de'); $ate = get('ate');
$formas = formas_pagamento();
$where = ['1=1']; $params = [];
if ($q !== '') { $where[] = '(c.nome LIKE ? OR pk.titulo LIKE ? OR CAST(r.id AS CHAR) = ?)'; array_push($params, "%$q%", "%$q%", ltrim($q, '#')); }
if (isset($formas[$forma])) { $where[] = 'p.forma = ?'; $params[] = $forma; }
if (in_array($sp, ['pendente', 'parcial', 'pago'], true)) { $where[] = 'r.status_pagamento = ?'; $params[] = $sp; }
if ($de  !== '' && data_valida($de))  { $where[] = 'p.data_pagamento >= ?'; $params[] = $de; }
if ($ate !== '' && data_valida($ate)) { $where[] = 'p.data_pagamento <= ?'; $params[] = $ate; }
$sqlWhere = implode(' AND ', $where);
$from = 'FROM pagamentos p JOIN reservas r ON r.id = p.reserva_id JOIN clientes c ON c.id = r.cliente_id JOIN pacotes pk ON pk.id = r.pacote_id';

$s = db()->prepare("SELECT COUNT(*), COALESCE(SUM(p.valor), 0) $from WHERE $sqlWhere"); $s->execute($params);
[$totalReg, $somaFiltro] = array_map('floatval', $s->fetch(PDO::FETCH_NUM));
$pg = paginar((int)$totalReg);
$s = db()->prepare("SELECT p.*, r.status_pagamento, r.valor_total, r.valor_pago, c.nome AS cliente_nome, pk.titulo $from WHERE $sqlWhere ORDER BY p.data_pagamento DESC, p.id DESC LIMIT {$pg['limite']} OFFSET {$pg['offset']}");
$s->execute($params);
$pagamentos = $s->fetchAll();

$kpi = db()->query("SELECT
   (SELECT COALESCE(SUM(valor),0) FROM pagamentos) AS recebido,
   (SELECT COALESCE(SUM(valor_total - valor_pago),0) FROM reservas WHERE status <> 'cancelada' AND status_pagamento <> 'pago') AS a_receber,
   (SELECT COUNT(*) FROM reservas WHERE status <> 'cancelada' AND status_pagamento = 'pago') AS pagas,
   (SELECT COUNT(*) FROM reservas WHERE status <> 'cancelada' AND status_pagamento = 'parcial') AS parciais,
   (SELECT COUNT(*) FROM reservas WHERE status <> 'cancelada' AND status_pagamento = 'pendente') AS pendentes")->fetch();

$titulo = 'Pagamentos'; $menu = 'pagamentos';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <div><h2>Controle de pagamentos</h2><p>Cada pagamento atualiza a situação financeira da reserva automaticamente.</p></div>
  <a class="btn btn-primary" href="<?= url('pagamentos/form.php') ?>"><?= icon('plus', 18) ?> Registrar pagamento</a>
</div>

<section class="kpis" style="margin-bottom:18px">
  <div class="card kpi green"><span class="ico"><?= icon('trend', 22) ?></span><div><small>Total recebido</small><strong><?= brl($kpi['recebido']) ?></strong></div></div>
  <div class="card kpi coral"><span class="ico"><?= icon('wallet', 22) ?></span><div><small>A receber</small><strong><?= brl($kpi['a_receber']) ?></strong></div></div>
  <div class="card kpi"><span class="ico"><?= icon('check', 22) ?></span><div><small>Reservas pagas</small><strong><?= (int)$kpi['pagas'] ?></strong></div></div>
  <div class="card kpi ocean"><span class="ico"><?= icon('clock', 22) ?></span><div><small>Parciais / pendentes</small><strong><?= (int)$kpi['parciais'] ?> / <?= (int)$kpi['pendentes'] ?></strong></div></div>
</section>

<div class="card">
  <form class="filters" data-live method="get" action="<?= url('pagamentos/index.php') ?>">
    <label class="field grow search"><span>Pesquisar</span><?= icon('search', 18) ?>
      <input type="search" name="q" value="<?= e($q) ?>" placeholder="Cliente, pacote ou nº da reserva"></label>
    <label class="field"><span>Forma</span><select name="forma"><option value="">Todas</option>
      <?php foreach ($formas as $k => $rot): ?><option value="<?= $k ?>" <?= $forma === $k ? 'selected' : '' ?>><?= e($rot) ?></option><?php endforeach; ?></select></label>
    <label class="field"><span>Situação da reserva</span><select name="situacao_pg"><option value="">Todas</option>
      <?php foreach (['pendente' => 'Pendente', 'parcial' => 'Parcial', 'pago' => 'Pago'] as $k => $rot): ?><option value="<?= $k ?>" <?= $sp === $k ? 'selected' : '' ?>><?= $rot ?></option><?php endforeach; ?></select></label>
    <label class="field"><span>Pago de</span><input type="date" name="de" value="<?= e($de) ?>"></label>
    <label class="field"><span>até</span><input type="date" name="ate" value="<?= e($ate) ?>"></label>
  </form>

  <div id="lista">
  <?php if (!$pagamentos): ?>
    <div class="empty"><strong>Nenhum pagamento encontrado</strong>Altere os filtros ou registre um pagamento.</div>
  <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Data</th><th>Reserva</th><th>Pacote</th><th>Forma</th><th class="num">Valor</th><th>Situação da reserva</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($pagamentos as $p): ?>
        <tr>
          <td><?= data_br($p['data_pagamento']) ?></td>
          <td><strong>#<?= (int)$p['reserva_id'] ?></strong> <?= e($p['cliente_nome']) ?><?php if ($p['observacao']): ?><small><?= e($p['observacao']) ?></small><?php endif; ?></td>
          <td><?= e($p['titulo']) ?></td>
          <td><?= e($formas[$p['forma']] ?? $p['forma']) ?></td>
          <td class="num"><strong><?= brl($p['valor']) ?></strong></td>
          <td><?= badge($p['status_pagamento']) ?><small><?= brl($p['valor_pago']) ?> de <?= brl($p['valor_total']) ?></small></td>
          <td><div class="row-actions">
            <a class="icon-btn" title="Editar" href="<?= url('pagamentos/form.php?id=' . $p['id']) ?>"><?= icon('edit', 18) ?></a>
            <form method="post" action="<?= url('pagamentos/excluir.php') ?>" data-confirm="O pagamento de <?= e(brl($p['valor'])) ?> da reserva #<?= (int)$p['reserva_id'] ?> será excluído e a situação financeira será recalculada.">
              <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <button class="icon-btn danger" title="Excluir" type="submit"><?= icon('trash', 18) ?></button></form>
          </div></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot><tr><td colspan="4">Total do filtro</td><td class="num"><?= brl($somaFiltro) ?></td><td colspan="2"></td></tr></tfoot>
    </table></div>
  <?php endif; ?>
  <?= paginacao_html($pg) ?>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
