<?php
require_once __DIR__ . '/includes/init.php';
registrar_historico('logout', 'usuarios', (int)$_SESSION['usuario']['id'], 'Saída do sistema');
$_SESSION = [];
session_destroy();
session_start();
flash('success', 'Você saiu do sistema com segurança.');
redirect('login.php');
