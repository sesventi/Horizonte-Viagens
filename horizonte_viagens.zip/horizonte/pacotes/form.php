<?php
require_once __DIR__ . '/../includes/init.php';

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$p = ['destino_id' => '', 'titulo' => '', 'preco' => '', 'duracao_dias' => '', 'vagas_total' => '', 'data_saida' => '', 'data_retorno' => '', 'ativo' => 1];
$ocupadas = 0;
if ($id) {
    $s = db()->prepare('SELECT * FROM vw_pacotes WHERE id = ?'); $s->execute([$id]);
    $p = $s->fetch();
    if (!$p) { flash('error', 'Pacote não encontrado.'); redirect('pacotes/index.php'); }
    $ocupadas = (int)$p['vagas_ocupadas'];
}

$erros = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $p = ['destino_id' => (int)post('destino_id'), 'titulo' => post('titulo'),
          'preco' => str_replace(',', '.', post('preco')), 'vagas_total' => (int)post('vagas_total'),
          'data_saida' => post('data_saida'), 'data_retorno' => post('data_retorno'),
          'ativo' => isset($_POST['ativo']) ? 1 : 0, 'duracao_dias' => ''];

    $s = db()->prepare('SELECT COUNT(*) FROM destinos WHERE id = ?'); $s->execute([$p['destino_id']]);
    if (!$s->fetchColumn())                                        $erros['destino_id'] = 'Escolha um destino.';
    if (mb_strlen($p['titulo']) < 5)                               $erros['titulo'] = 'Informe o título do pacote (mín. 5 caracteres).';
    if (!is_numeric($p['preco']) || (float)$p['preco'] <= 0)       $erros['preco'] = 'Informe um preço maior que zero.';
    if ($p['vagas_total'] < 1 || $p['vagas_total'] > 500)          $erros['vagas_total'] = 'Informe de 1 a 500 vagas.';
    elseif ($p['vagas_total'] < $ocupadas)                         $erros['vagas_total'] = "Já existem $ocupadas vaga(s) reservada(s); o total não pode ser menor.";
    if (!data_valida($p['data_saida']))                            $erros['data_saida'] = 'Data de saída inválida.';
    elseif (!$id && $p['data_saida'] < date('Y-m-d'))              $erros['data_saida'] = 'A data de saída não pode estar no passado.';
    if (!data_valida($p['data_retorno']))                          $erros['data_retorno'] = 'Data de retorno inválida.';
    elseif (!isset($erros['data_saida']) && $p['data_retorno'] < $p['data_saida']) $erros['data_retorno'] = 'O retorno deve ser igual ou posterior à saída.';

    if (!$erros) {
        $p['duracao_dias'] = (int)((strtotime($p['data_retorno']) - strtotime($p['data_saida'])) / 86400) + 1;
        $dados = [$p['destino_id'], $p['titulo'], round((float)$p['preco'], 2), $p['duracao_dias'], $p['vagas_total'], $p['data_saida'], $p['data_retorno'], $p['ativo']];
        try {
            if ($id) {
                db()->prepare('UPDATE pacotes SET destino_id=?, titulo=?, preco=?, duracao_dias=?, vagas_total=?, data_saida=?, data_retorno=?, ativo=? WHERE id=?')
                    ->execute([...$dados, $id]);
                registrar_historico('editou', 'pacotes', $id, 'Pacote "' . $p['titulo'] . '" atualizado');
                flash('success', 'Pacote atualizado com sucesso.');
            } else {
                db()->prepare('INSERT INTO pacotes (destino_id, titulo, preco, duracao_dias, vagas_total, data_saida, data_retorno, ativo) VALUES (?,?,?,?,?,?,?,?)')
                    ->execute($dados);
                registrar_historico('criou', 'pacotes', (int)db()->lastInsertId(), 'Pacote "' . $p['titulo'] . '" criado');
                flash('success', 'Pacote criado com sucesso.');
            }
            redirect('pacotes/index.php');
        } catch (PDOException $ex) { $erros['geral'] = 'Não foi possível salvar o pacote.'; }
    }
}
$destinos = db()->query('SELECT id, cidade, pais FROM destinos ORDER BY cidade')->fetchAll();

$titulo = $id ? 'Editar pacote' : 'Novo pacote'; $menu = 'pacotes';
require __DIR__ . '/../includes/header.php';
$err = fn(string $c) => isset($erros[$c]) ? '<span class="err">' . e($erros[$c]) . '</span>' : '';
$inv = fn(string $c) => isset($erros[$c]) ? ' invalid' : '';
?>
<div class="page-head"><div><h2><?= e($titulo) ?></h2><p>Defina destino, preço, datas e quantidade de vagas.</p></div>
  <a class="btn btn-ghost" href="<?= url('pacotes/index.php') ?>">Voltar</a></div>

<?php if (!$destinos): ?>
  <div class="card empty"><strong>Cadastre um destino primeiro</strong><a class="btn btn-primary" href="<?= url('destinos/form.php') ?>">Novo destino</a></div>
<?php else: ?>
<form method="post" class="card form-card" data-validate>
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
  <?php if (isset($erros['geral'])): ?><div class="alert alert-error"><?= icon('alert', 18) ?><span><?= e($erros['geral']) ?></span></div><?php endif; ?>
  <div class="form-grid">
    <label class="field<?= $inv('titulo') ?> full"><span>Título do pacote</span><input name="titulo" value="<?= e($p['titulo']) ?>" maxlength="120" required><?= $err('titulo') ?></label>
    <label class="field<?= $inv('destino_id') ?>"><span>Destino</span><select name="destino_id" required><option value="">Selecione...</option>
      <?php foreach ($destinos as $d): ?><option value="<?= (int)$d['id'] ?>" <?= (int)$p['destino_id'] === (int)$d['id'] ? 'selected' : '' ?>><?= e($d['cidade']) ?> - <?= e($d['pais']) ?></option><?php endforeach; ?></select><?= $err('destino_id') ?></label>
    <label class="field<?= $inv('preco') ?>"><span>Preço por pessoa (R$)</span><input type="number" name="preco" step="0.01" min="0.01" value="<?= e($p['preco']) ?>" required><?= $err('preco') ?>
      <?php if ($id): ?><span class="hint">Reservas já feitas mantêm o valor da época da reserva.</span><?php endif; ?></label>
    <label class="field<?= $inv('data_saida') ?>"><span>Data de saída</span><input type="date" id="data_saida" name="data_saida" value="<?= e($p['data_saida']) ?>" required><?= $err('data_saida') ?></label>
    <label class="field<?= $inv('data_retorno') ?>"><span>Data de retorno</span><input type="date" id="data_retorno" name="data_retorno" value="<?= e($p['data_retorno']) ?>" required><?= $err('data_retorno') ?></label>
    <label class="field"><span>Duração (dias)</span><input id="duracao_dias" value="<?= e($p['duracao_dias']) ?>" readonly><span class="hint">Calculada automaticamente pelas datas.</span></label>
    <label class="field<?= $inv('vagas_total') ?>"><span>Quantidade de vagas</span><input type="number" name="vagas_total" min="1" max="500" value="<?= e($p['vagas_total']) ?>" required><?= $err('vagas_total') ?>
      <?php if ($id): ?><span class="hint"><?= $ocupadas ?> vaga(s) já reservada(s).</span><?php endif; ?></label>
    <label class="field full check"><input type="checkbox" name="ativo" value="1" <?= $p['ativo'] ? 'checked' : '' ?>> Disponibilizar este pacote para reservas</label>
  </div>
  <div class="form-actions"><a class="btn btn-ghost" href="<?= url('pacotes/index.php') ?>">Cancelar</a>
    <button class="btn btn-primary" type="submit"><?= $id ? 'Salvar alterações' : 'Criar pacote' ?></button></div>
</form>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
