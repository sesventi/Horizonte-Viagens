<?php
require_once __DIR__ . '/../includes/init.php';

$q = get('q'); $destino = (int)get('destino'); $sit = get('situacao'); $de = get('de'); $ate = get('ate');
$where = ['1=1']; $params = [];
if ($q !== '')      { $where[] = '(v.titulo LIKE ? OR v.cidade LIKE ? OR v.pais LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%"); }
if ($destino > 0)   { $where[] = 'v.destino_id = ?'; $params[] = $destino; }
if ($de  !== '' && data_valida($de))  { $where[] = 'v.data_saida >= ?'; $params[] = $de; }
if ($ate !== '' && data_valida($ate)) { $where[] = 'v.data_saida <= ?'; $params[] = $ate; }
$filtrosSit = [
    'disponivel' => 'v.ativo = 1 AND v.data_saida >= CURDATE() AND v.vagas_disponiveis > 0',
    'esgotado'   => 'v.ativo = 1 AND v.data_saida >= CURDATE() AND v.vagas_disponiveis <= 0',
    'encerrado'  => 'v.ativo = 1 AND v.data_saida < CURDATE()',
    'inativo'    => 'v.ativo = 0',
];
if (isset($filtrosSit[$sit])) $where[] = $filtrosSit[$sit];
$sqlWhere = implode(' AND ', $where);

$s = db()->prepare("SELECT COUNT(*) FROM vw_pacotes v WHERE $sqlWhere"); $s->execute($params);
$pg = paginar((int)$s->fetchColumn());
$s = db()->prepare("SELECT v.* FROM vw_pacotes v WHERE $sqlWhere ORDER BY v.data_saida DESC LIMIT {$pg['limite']} OFFSET {$pg['offset']}");
$s->execute($params);
$pacotes = $s->fetchAll();
$listaDestinos = db()->query('SELECT id, cidade, pais FROM destinos ORDER BY cidade')->fetchAll();

$titulo = 'Pacotes turísticos'; $menu = 'pacotes';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <div><h2>Pacotes turísticos</h2><p>Monte as viagens e acompanhe as vagas em tempo real.</p></div>
  <a class="btn btn-primary" href="<?= url('pacotes/form.php') ?>"><?= icon('plus', 18) ?> Novo pacote</a>
</div>

<div class="card">
  <form class="filters" data-live method="get" action="<?= url('pacotes/index.php') ?>">
    <label class="field grow search"><span>Pesquisar</span><?= icon('search', 18) ?>
      <input type="search" name="q" value="<?= e($q) ?>" placeholder="Título, cidade ou país"></label>
    <label class="field"><span>Destino</span><select name="destino"><option value="">Todos</option>
      <?php foreach ($listaDestinos as $d): ?><option value="<?= (int)$d['id'] ?>" <?= $destino === (int)$d['id'] ? 'selected' : '' ?>><?= e($d['cidade']) ?></option><?php endforeach; ?></select></label>
    <label class="field"><span>Situação</span><select name="situacao"><option value="">Todas</option>
      <?php foreach (['disponivel' => 'Disponível', 'esgotado' => 'Esgotado', 'encerrado' => 'Encerrado', 'inativo' => 'Indisponível'] as $k => $r): ?>
        <option value="<?= $k ?>" <?= $sit === $k ? 'selected' : '' ?>><?= $r ?></option><?php endforeach; ?></select></label>
    <label class="field"><span>Saída de</span><input type="date" name="de" value="<?= e($de) ?>"></label>
    <label class="field"><span>até</span><input type="date" name="ate" value="<?= e($ate) ?>"></label>
  </form>

  <div id="lista">
  <?php if (!$pacotes): ?>
    <div class="empty"><strong>Nenhum pacote encontrado</strong>Altere os filtros ou crie um novo pacote.</div>
  <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Pacote</th><th>Saída / retorno</th><th class="num">Duração</th><th class="num">Preço</th><th>Vagas</th><th>Situação</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($pacotes as $p): $sp = pacote_situacao($p); $pct = round($p['vagas_ocupadas'] * 100 / max(1, $p['vagas_total'])); ?>
        <tr>
          <td><strong><?= e($p['titulo']) ?></strong><small><?= e($p['cidade']) ?>, <?= e($p['pais']) ?></small></td>
          <td><?= data_br($p['data_saida']) ?><small>até <?= data_br($p['data_retorno']) ?></small></td>
          <td class="num"><?= (int)$p['duracao_dias'] ?> dias</td>
          <td class="num"><?= brl($p['preco']) ?></td>
          <td style="min-width:130px"><strong><?= (int)$p['vagas_disponiveis'] ?></strong> de <?= (int)$p['vagas_total'] ?> livres
            <div class="progress <?= $p['vagas_disponiveis'] <= 0 ? 'full' : '' ?>"><i style="width:<?= $pct ?>%"></i></div></td>
          <td><?= badge($sp) ?></td>
          <td><div class="row-actions">
            <?php if ($sp === 'ativo'): ?><a class="btn btn-sm btn-ghost" href="<?= url('reservas/form.php?pacote_id=' . $p['id']) ?>">Reservar</a><?php endif; ?>
            <a class="icon-btn" title="Editar" href="<?= url('pacotes/form.php?id=' . $p['id']) ?>"><?= icon('edit', 18) ?></a>
            <form method="post" action="<?= url('pacotes/excluir.php') ?>" data-confirm="O pacote “<?= e($p['titulo']) ?>” será removido permanentemente. Deseja continuar?">
              <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <button class="icon-btn danger" title="Excluir" type="submit"><?= icon('trash', 18) ?></button></form>
          </div></td>
        </tr>
      <?php endforeach; ?>
      </tbody></table></div>
  <?php endif; ?>
  <?= paginacao_html($pg) ?>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
