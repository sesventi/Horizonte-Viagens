<?php
require_once __DIR__ . '/../includes/init.php';
exigir_post();
$id = (int)($_POST['id'] ?? 0);

$s = db()->prepare('SELECT titulo FROM pacotes WHERE id = ?'); $s->execute([$id]);
$titulo = $s->fetchColumn();
if ($titulo === false) { flash('error', 'Pacote não encontrado.'); redirect('pacotes/index.php'); }

$s = db()->prepare('SELECT COUNT(*) FROM reservas WHERE pacote_id = ?'); $s->execute([$id]);
if ((int)$s->fetchColumn() > 0) {
    flash('error', 'Não é possível excluir "' . $titulo . '": há reservas vinculadas. Edite o pacote e desmarque a disponibilidade para reservas.');
    redirect('pacotes/index.php');
}
try {
    db()->prepare('DELETE FROM pacotes WHERE id = ?')->execute([$id]);
    registrar_historico('excluiu', 'pacotes', $id, 'Pacote "' . $titulo . '" excluído');
    flash('success', 'Pacote excluído com sucesso.');
} catch (PDOException $e) {
    flash('error', 'Não foi possível excluir o pacote.');
}
redirect('pacotes/index.php');
