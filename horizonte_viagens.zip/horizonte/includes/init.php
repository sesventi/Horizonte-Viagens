<?php
/**
 * Inicialização comum a todas as páginas: sessão, configuração, banco,
 * funções auxiliares e proteção de acesso (exige login).
 * Páginas públicas (login) definem PUBLIC_PAGE antes de incluir este arquivo.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
date_default_timezone_set('America/Sao_Paulo');

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/icons.php';

if (!defined('PUBLIC_PAGE') && empty($_SESSION['usuario'])) {
    redirect('login.php');
}
