    </main>
  </div>
</div>

<!-- Janela de confirmação reutilizável (exclusão / cancelamento) -->
<dialog id="confirmDialog" class="modal">
  <form method="dialog">
    <div class="modal-icon"><?= icon('alert', 26) ?></div>
    <h3 id="confirmTitle">Confirmar ação</h3>
    <p id="confirmText"></p>
    <div class="modal-actions">
      <button value="cancel" class="btn btn-ghost">Voltar</button>
      <button value="ok" class="btn btn-danger" id="confirmOk">Confirmar</button>
    </div>
  </form>
</dialog>

<script src="<?= url('assets/js/app.js') ?>"></script>
<?php foreach (($scripts ?? []) as $s): ?>
<script src="<?= url('assets/js/' . $s) ?>"></script>
<?php endforeach; ?>
</body>
</html>
