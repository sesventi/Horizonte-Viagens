<?php
/** Funções auxiliares usadas em todo o sistema. */

/* ---------- Saída e navegação ---------- */
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function url(string $path = ''): string { return BASE_URL . '/' . ltrim($path, '/'); }
function redirect(string $path)
{
    header('Location: ' . url($path));
    exit;
}

/* ---------- Mensagens (flash) ---------- */
function flash(string $tipo, string $msg): void { $_SESSION['flash'][] = ['tipo' => $tipo, 'msg' => $msg]; }
function flash_render(): string
{
    $html = '';
    foreach ($_SESSION['flash'] ?? [] as $f) {
        $ic = $f['tipo'] === 'success' ? 'check' : 'alert';
        $html .= '<div class="alert alert-' . e($f['tipo']) . '" role="alert">' . icon($ic, 18)
               . '<span>' . e($f['msg']) . '</span><button type="button" class="alert-close" aria-label="Fechar">&times;</button></div>';
    }
    unset($_SESSION['flash']);
    return $html;
}

/* ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function csrf_check(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        die('Sessão expirada ou requisição inválida. Volte e tente novamente.');
    }
}
function exigir_post(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); die('Método não permitido.'); }
    csrf_check();
}

/* ---------- Formatação ---------- */
function brl($v): string { return 'R$ ' . number_format((float)$v, 2, ',', '.'); }
function data_br(?string $d): string { return $d ? date('d/m/Y', strtotime($d)) : '-'; }
function datahora_br(?string $d): string { return $d ? date('d/m/Y H:i', strtotime($d)) : '-'; }
function so_digitos(string $s): string { return preg_replace('/\D+/', '', $s); }
function fmt_cpf(string $c): string { return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $c); }
function fmt_tel(string $t): string { return $t; }
function iniciais(string $nome): string
{
    $p = preg_split('/\s+/', trim($nome));
    return mb_strtoupper(mb_substr($p[0], 0, 1) . (count($p) > 1 ? mb_substr(end($p), 0, 1) : ''));
}
function formas_pagamento(): array
{
    return ['pix' => 'Pix', 'cartao_credito' => 'Cartão de crédito', 'cartao_debito' => 'Cartão de débito',
            'boleto' => 'Boleto', 'dinheiro' => 'Dinheiro', 'transferencia' => 'Transferência'];
}

/* ---------- Selos de situação ---------- */
function rotulo_status(string $status): string
{
    $map = ['pendente' => 'Pendente', 'confirmada' => 'Confirmada', 'cancelada' => 'Cancelada',
            'parcial' => 'Parcial', 'pago' => 'Pago', 'ativo' => 'Disponível', 'inativo' => 'Indisponível',
            'esgotado' => 'Esgotado', 'encerrado' => 'Encerrado'];
    return $map[$status] ?? $status;
}
function badge(string $status): string
{
    return '<span class="badge badge-' . e($status) . '">' . e(rotulo_status($status)) . '</span>';
}

/* ---------- Validações ---------- */
function cpf_valido(string $cpf): bool
{
    $cpf = so_digitos($cpf);
    if (strlen($cpf) !== 11 || preg_match('/^(\d)\1{10}$/', $cpf)) return false;
    for ($t = 9; $t < 11; $t++) {
        $soma = 0;
        for ($i = 0; $i < $t; $i++) $soma += $cpf[$i] * (($t + 1) - $i);
        $dig = ((10 * $soma) % 11) % 10;
        if ((int)$cpf[$t] !== $dig) return false;
    }
    return true;
}
function data_valida(string $d): bool
{
    $x = DateTime::createFromFormat('Y-m-d', $d);
    return $x && $x->format('Y-m-d') === $d;
}
function post(string $campo): string { return trim((string)($_POST[$campo] ?? '')); }
function get(string $campo): string { return trim((string)($_GET[$campo] ?? '')); }

/* ---------- Histórico de alterações ---------- */
function registrar_historico(string $acao, string $tabela, ?int $id, string $detalhes = ''): void
{
    $u = $_SESSION['usuario'] ?? ['id' => null, 'nome' => 'Sistema'];
    db()->prepare('INSERT INTO historico (usuario_id, usuario_nome, acao, tabela, registro_id, detalhes) VALUES (?,?,?,?,?,?)')
        ->execute([$u['id'], $u['nome'], $acao, $tabela, $id, mb_substr($detalhes, 0, 500)]);
}

/* ---------- Paginação ---------- */
function paginar(int $total, int $porPagina = 8): array
{
    $paginas = max(1, (int)ceil($total / $porPagina));
    $pagina  = min(max(1, (int)($_GET['pagina'] ?? 1)), $paginas);
    return ['pagina' => $pagina, 'paginas' => $paginas, 'limite' => $porPagina,
            'offset' => ($pagina - 1) * $porPagina, 'total' => $total];
}
function paginacao_html(array $p): string
{
    $html = '<div class="pager"><span>' . $p['total'] . ' registro(s) &middot; página ' . $p['pagina'] . ' de ' . $p['paginas'] . '</span>';
    if ($p['paginas'] > 1) {
        $link = function (int $n, string $txt, bool $ativo = false, bool $off = false): string {
            if ($off) return '<span class="pg off">' . $txt . '</span>';
            $q = $_GET; $q['pagina'] = $n;
            return '<a class="pg' . ($ativo ? ' on' : '') . '" href="?' . e(http_build_query($q)) . '">' . $txt . '</a>';
        };
        $html .= '<nav class="pgs">' . $link($p['pagina'] - 1, '&lsaquo;', false, $p['pagina'] <= 1);
        $ini = max(1, $p['pagina'] - 2); $fim = min($p['paginas'], $p['pagina'] + 2);
        for ($i = $ini; $i <= $fim; $i++) $html .= $link($i, (string)$i, $i === $p['pagina']);
        $html .= $link($p['pagina'] + 1, '&rsaquo;', false, $p['pagina'] >= $p['paginas']) . '</nav>';
    }
    return $html . '</div>';
}

/* ---------- Regras de negócio: vagas e situação financeira ---------- */

/** Vagas livres de um pacote (reservas canceladas não ocupam vaga). */
function vagas_disponiveis(int $pacoteId, int $ignorarReserva = 0): int
{
    $s = db()->prepare("SELECT p.vagas_total - COALESCE(SUM(r.qtd_pessoas), 0)
                          FROM pacotes p
                          LEFT JOIN reservas r ON r.pacote_id = p.id AND r.status <> 'cancelada' AND r.id <> ?
                         WHERE p.id = ? GROUP BY p.id");
    $s->execute([$ignorarReserva, $pacoteId]);
    return (int)$s->fetchColumn();
}

/**
 * Recalcula valor pago e situação financeira da reserva a partir dos pagamentos.
 * Se a reserva estava pendente e recebeu algum pagamento, passa a confirmada.
 */
function atualizar_financeiro(int $reservaId): void
{
    $pdo = db();
    $s = $pdo->prepare('SELECT valor_total, status FROM reservas WHERE id = ?');
    $s->execute([$reservaId]);
    if (!($r = $s->fetch())) return;

    $s = $pdo->prepare('SELECT COALESCE(SUM(valor), 0) FROM pagamentos WHERE reserva_id = ?');
    $s->execute([$reservaId]);
    $pago = (float)$s->fetchColumn();

    $sit    = $pago <= 0 ? 'pendente' : ($pago >= (float)$r['valor_total'] ? 'pago' : 'parcial');
    $status = ($r['status'] === 'pendente' && $pago > 0) ? 'confirmada' : $r['status'];
    $pdo->prepare('UPDATE reservas SET valor_pago = ?, status_pagamento = ?, status = ? WHERE id = ?')
        ->execute([$pago, $sit, $status, $reservaId]);
}

/* ---------- Upload de imagem (destinos) ---------- */
function salvar_imagem(array $file): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if ($file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Falha no envio da imagem.');
    if ($file['size'] > 2 * 1024 * 1024) throw new RuntimeException('A imagem deve ter no máximo 2 MB.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $ext  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if (!$ext) throw new RuntimeException('Formato de imagem inválido. Use JPG, PNG ou WEBP.');
    $nome = bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], ROOT_PATH . '/assets/uploads/' . $nome))
        throw new RuntimeException('Não foi possível salvar a imagem.');
    return 'assets/uploads/' . $nome;
}
function remover_imagem(?string $caminho): void
{
    if ($caminho && str_starts_with($caminho, 'assets/uploads/') && is_file(ROOT_PATH . '/' . $caminho))
        @unlink(ROOT_PATH . '/' . $caminho);
}

/* ---------- Situação de um pacote (calculada) ---------- */
function pacote_situacao(array $p): string
{
    if (!(int)$p['ativo'])                       return 'inativo';
    if ($p['data_saida'] < date('Y-m-d'))        return 'encerrado';
    if ((int)$p['vagas_disponiveis'] <= 0)       return 'esgotado';
    return 'ativo';
}
