<?php
/**
 * Layout superior: <head>, menu lateral e barra de topo.
 * Variáveis esperadas: $titulo (string) e $menu (chave do item ativo).
 */
$u = $_SESSION['usuario'];
$nav = [
    ['dashboard',  'dashboard.php',            'Dashboard',  'home'],
    ['clientes',   'clientes/index.php',       'Clientes',   'users'],
    ['destinos',   'destinos/index.php',       'Destinos',   'map'],
    ['pacotes',    'pacotes/index.php',        'Pacotes',    'package'],
    ['reservas',   'reservas/index.php',       'Reservas',   'calendar'],
    ['pagamentos', 'pagamentos/index.php',     'Pagamentos', 'wallet'],
    ['relatorios', 'relatorios/index.php',     'Relatórios', 'chart'],
    ['historico',  'historico/index.php',      'Histórico',  'clock'],
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($titulo ?? 'Painel') ?> | <?= e(APP_NAME) ?></title>
  <link rel="icon" href="<?= url('assets/images/logo-mark.svg') ?>" type="image/svg+xml">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600&family=Sora:wght@500;600;700&display=swap">
  <link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body>
<div class="app">
  <div class="scrim" id="scrim"></div>
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="<?= url('dashboard.php') ?>">
      <img src="<?= url('assets/images/logo-mark.svg') ?>" alt="" width="38" height="38">
      <span class="brand-text"><strong>Horizonte</strong><small>Viagens</small></span>
    </a>
    <nav class="nav" aria-label="Menu principal">
      <?php foreach ($nav as [$chave, $href, $rotulo, $ic]): ?>
        <a href="<?= url($href) ?>" class="<?= ($menu ?? '') === $chave ? 'active' : '' ?>"><?= icon($ic) ?><span><?= e($rotulo) ?></span></a>
      <?php endforeach; ?>
    </nav>
    <div class="side-user">
      <span class="avatar"><?= e(iniciais($u['nome'])) ?></span>
      <div><strong><?= e($u['nome']) ?></strong><small><?= e(ucfirst($u['perfil'])) ?></small></div>
      <a href="<?= url('logout.php') ?>" class="icon-btn" title="Sair" aria-label="Sair"><?= icon('logout', 18) ?></a>
    </div>
  </aside>

  <div class="main">
    <header class="topbar">
      <button class="icon-btn menu-toggle" id="menuToggle" aria-label="Abrir menu"><?= icon('menu') ?></button>
      <h1><?= e($titulo ?? '') ?></h1>
      <span class="today"><?= date('d/m/Y') ?></span>
    </header>
    <main class="content">
      <?= flash_render() ?>
