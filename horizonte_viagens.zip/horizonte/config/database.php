<?php
/**
 * Conexão reutilizável com o banco (PDO + consultas preparadas).
 * Uso: $stmt = db()->prepare('SELECT ... WHERE id = ?');
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            die('<h2 style="font-family:sans-serif">Não foi possível conectar ao banco de dados.</h2>'
              . '<p style="font-family:sans-serif">Verifique se o MySQL está ativo no XAMPP, se o arquivo '
              . '<code>database/horizonte_viagens.sql</code> foi importado e se as credenciais em '
              . '<code>config/config.php</code> estão corretas.</p>');
        }
    }
    return $pdo;
}
