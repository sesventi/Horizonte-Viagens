<?php
/**
 * Configurações gerais do sistema Horizonte Viagens.
 * Ajuste as credenciais do banco caso seu MySQL use senha.
 */
define('APP_NAME', 'Horizonte Viagens');

define('DB_HOST', 'localhost');
define('DB_NAME', 'horizonte_viagens');
define('DB_USER', 'root');   // padrão do XAMPP
define('DB_PASS', '');       // padrão do XAMPP (sem senha)

define('ROOT_PATH', str_replace('\\', '/', realpath(__DIR__ . '/..')));

// BASE_URL é descoberta automaticamente (ex.: /horizonte), então o
// projeto funciona em qualquer subpasta do htdocs.
$__doc = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'] ?? ''));
define('BASE_URL', rtrim(substr(ROOT_PATH, strlen($__doc)), '/'));
unset($__doc);
