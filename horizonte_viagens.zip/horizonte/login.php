<?php
define('PUBLIC_PAGE', true);
require_once __DIR__ . '/includes/init.php';

if (!empty($_SESSION['usuario'])) redirect('dashboard.php');

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $usuario = post('usuario');
    $senha   = (string)($_POST['senha'] ?? '');

    if ($usuario === '' || $senha === '') {
        $erro = 'Informe usuário e senha.';
    } else {
        $s = db()->prepare('SELECT id, nome, usuario, senha_hash, perfil FROM usuarios WHERE usuario = ? AND ativo = 1');
        $s->execute([$usuario]);
        $u = $s->fetch();
        if ($u && password_verify($senha, $u['senha_hash'])) {
            session_regenerate_id(true);
            $_SESSION['usuario'] = ['id' => (int)$u['id'], 'nome' => $u['nome'], 'usuario' => $u['usuario'], 'perfil' => $u['perfil']];
            registrar_historico('login', 'usuarios', (int)$u['id'], 'Entrada no sistema');
            redirect('dashboard.php');
        }
        $erro = 'Usuário ou senha incorretos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Entrar | <?= e(APP_NAME) ?></title>
  <link rel="icon" href="<?= url('assets/images/logo-mark.svg') ?>" type="image/svg+xml">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600&family=Sora:wght@500;600;700&display=swap">
  <link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body class="login-page">
  <section class="login-hero" aria-hidden="true">
    <svg viewBox="0 0 800 900" preserveAspectRatio="xMidYMax slice">
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#0B3C5D"/><stop offset=".55" stop-color="#0E8FA0"/><stop offset="1" stop-color="#F2B36B"/>
        </linearGradient>
      </defs>
      <rect width="800" height="900" fill="url(#sky)"/>
      <circle cx="400" cy="560" r="150" fill="#F2994A"/>
      <rect y="560" width="800" height="340" fill="#0B3C5D"/>
      <g stroke="#7BD3C6" stroke-width="5" stroke-linecap="round" opacity=".85">
        <path d="M250 585h300"/><path d="M300 615h200"/><path d="M200 650h400" opacity=".7"/><path d="M280 690h240" opacity=".55"/><path d="M160 740h480" opacity=".4"/>
      </g>
    </svg>
    <div class="login-tagline">
      <h2>Cada viagem começa<br>numa boa organização.</h2>
      <p>Clientes, pacotes, reservas e pagamentos da agência em um só lugar.</p>
    </div>
  </section>

  <section class="login-panel">
    <form method="post" class="login-card" novalidate>
      <div class="brand brand-dark">
        <img src="<?= url('assets/images/logo-mark.svg') ?>" alt="" width="46" height="46">
        <span class="brand-text"><strong>Horizonte</strong><small>Viagens</small></span>
      </div>
      <h1>Acesse o painel</h1>
      <p class="muted">Entre com seu usuário da agência.</p>

      <?= flash_render() ?>
      <?php if ($erro): ?><div class="alert alert-error" role="alert"><?= icon('alert', 18) ?><span><?= e($erro) ?></span></div><?php endif; ?>

      <?= csrf_field() ?>
      <label class="field"><span>Usuário</span>
        <input type="text" name="usuario" value="<?= e($_POST['usuario'] ?? '') ?>" autocomplete="username" required autofocus>
      </label>
      <label class="field"><span>Senha</span>
        <input type="password" name="senha" autocomplete="current-password" required>
      </label>
      <button class="btn btn-primary btn-block" type="submit">Entrar</button>
      <p class="demo-hint">Demonstração: usuário <code>admin</code> &middot; senha <code>admin123</code></p>
    </form>
  </section>
</body>
</html>
