<?php
require_once __DIR__ . '/../includes/init.php';

$q = get('q'); $pais = get('pais');
$where = ['1=1']; $params = [];
if ($q !== '')    { $where[] = '(d.cidade LIKE ? OR d.pais LIKE ? OR d.descricao LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%"); }
if ($pais !== '') { $where[] = 'd.pais = ?'; $params[] = $pais; }
$sqlWhere = implode(' AND ', $where);

$s = db()->prepare("SELECT COUNT(*) FROM destinos d WHERE $sqlWhere"); $s->execute($params);
$pg = paginar((int)$s->fetchColumn(), 9);

$s = db()->prepare("SELECT d.*, (SELECT COUNT(*) FROM pacotes p WHERE p.destino_id = d.id) AS pacotes
                      FROM destinos d WHERE $sqlWhere ORDER BY d.cidade LIMIT {$pg['limite']} OFFSET {$pg['offset']}");
$s->execute($params);
$destinos = $s->fetchAll();
$paises = db()->query('SELECT DISTINCT pais FROM destinos ORDER BY pais')->fetchAll(PDO::FETCH_COLUMN);

$titulo = 'Destinos'; $menu = 'destinos';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <div><h2>Destinos turísticos</h2><p>Cidades e países que a agência oferece.</p></div>
  <a class="btn btn-primary" href="<?= url('destinos/form.php') ?>"><?= icon('plus', 18) ?> Novo destino</a>
</div>

<form class="filters" data-live method="get" action="<?= url('destinos/index.php') ?>">
  <label class="field grow search"><span>Pesquisar</span><?= icon('search', 18) ?>
    <input type="search" name="q" value="<?= e($q) ?>" placeholder="Cidade, país ou descrição"></label>
  <label class="field"><span>País</span><select name="pais"><option value="">Todos</option>
    <?php foreach ($paises as $p): ?><option <?= $p === $pais ? 'selected' : '' ?>><?= e($p) ?></option><?php endforeach; ?></select></label>
</form>

<div id="lista">
<?php if (!$destinos): ?>
  <div class="card empty"><strong>Nenhum destino encontrado</strong>Cadastre um destino para começar a montar pacotes.</div>
<?php else: ?>
  <div class="dest-grid">
  <?php foreach ($destinos as $d): ?>
    <article class="dest">
      <?php if ($d['imagem']): ?>
        <div class="dest-img" style="background-image:linear-gradient(transparent 40%,rgba(0,0,0,.55)),url('<?= e(url($d['imagem'])) ?>')"><?= e($d['cidade']) ?></div>
      <?php else: ?>
        <div class="dest-img ph"><?= e($d['cidade']) ?></div>
      <?php endif; ?>
      <div class="dest-body"><strong><?= e($d['cidade']) ?>, <?= e($d['pais']) ?></strong><p><?= e($d['descricao']) ?></p></div>
      <div class="dest-foot">
        <span class="muted"><?= (int)$d['pacotes'] ?> pacote(s)</span>
        <div class="row-actions">
          <a class="icon-btn" title="Editar" href="<?= url('destinos/form.php?id=' . $d['id']) ?>"><?= icon('edit', 18) ?></a>
          <form method="post" action="<?= url('destinos/excluir.php') ?>" data-confirm="O destino <?= e($d['cidade']) ?> será removido permanentemente. Deseja continuar?">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
            <button class="icon-btn danger" title="Excluir" type="submit"><?= icon('trash', 18) ?></button></form>
        </div>
      </div>
    </article>
  <?php endforeach; ?>
  </div>
<?php endif; ?>
  <?= paginacao_html($pg) ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
