<?php
require_once __DIR__ . '/../includes/init.php';

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$d = ['cidade' => '', 'pais' => '', 'descricao' => '', 'imagem' => null];
if ($id) {
    $s = db()->prepare('SELECT * FROM destinos WHERE id = ?'); $s->execute([$id]);
    $d = $s->fetch();
    if (!$d) { flash('error', 'Destino não encontrado.'); redirect('destinos/index.php'); }
}

$erros = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $imagemAtual = $d['imagem'];
    $d = ['cidade' => post('cidade'), 'pais' => post('pais'), 'descricao' => post('descricao'), 'imagem' => $imagemAtual];

    if (mb_strlen($d['cidade']) < 2)     $erros['cidade'] = 'Informe a cidade.';
    if (mb_strlen($d['pais']) < 2)       $erros['pais'] = 'Informe o país.';
    if (mb_strlen($d['descricao']) < 20) $erros['descricao'] = 'A descrição precisa ter pelo menos 20 caracteres.';

    if (!$erros) {
        $s = db()->prepare('SELECT COUNT(*) FROM destinos WHERE cidade = ? AND pais = ? AND id <> ?');
        $s->execute([$d['cidade'], $d['pais'], $id]);
        if ($s->fetchColumn() > 0) $erros['cidade'] = 'Este destino já está cadastrado.';
    }
    $novaImagem = null;
    if (!$erros) {
        try { $novaImagem = salvar_imagem($_FILES['imagem'] ?? []); }
        catch (RuntimeException $ex) { $erros['imagem'] = $ex->getMessage(); }
    }
    if (!$erros) {
        try {
            $caminho = $novaImagem ?: $imagemAtual;
            if ($id) {
                db()->prepare('UPDATE destinos SET cidade=?, pais=?, descricao=?, imagem=? WHERE id=?')
                    ->execute([$d['cidade'], $d['pais'], $d['descricao'], $caminho, $id]);
                if ($novaImagem) remover_imagem($imagemAtual);
                registrar_historico('editou', 'destinos', $id, 'Destino "' . $d['cidade'] . '" atualizado');
                flash('success', 'Destino atualizado com sucesso.');
            } else {
                db()->prepare('INSERT INTO destinos (cidade, pais, descricao, imagem) VALUES (?,?,?,?)')
                    ->execute([$d['cidade'], $d['pais'], $d['descricao'], $caminho]);
                registrar_historico('criou', 'destinos', (int)db()->lastInsertId(), 'Destino "' . $d['cidade'] . '" cadastrado');
                flash('success', 'Destino cadastrado com sucesso.');
            }
            redirect('destinos/index.php');
        } catch (PDOException $ex) {
            if ($novaImagem) remover_imagem($novaImagem);
            $erros['geral'] = 'Não foi possível salvar o destino.';
        }
    }
}

$titulo = $id ? 'Editar destino' : 'Novo destino'; $menu = 'destinos';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><div><h2><?= e($titulo) ?></h2><p>Informe cidade, país, descrição e, se quiser, uma imagem.</p></div>
  <a class="btn btn-ghost" href="<?= url('destinos/index.php') ?>">Voltar</a></div>

<form method="post" class="card form-card" enctype="multipart/form-data" data-validate>
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
  <?php if (isset($erros['geral'])): ?><div class="alert alert-error"><?= icon('alert', 18) ?><span><?= e($erros['geral']) ?></span></div><?php endif; ?>
  <div class="form-grid">
    <label class="field <?= isset($erros['cidade']) ? 'invalid' : '' ?>"><span>Cidade</span>
      <input name="cidade" value="<?= e($d['cidade']) ?>" maxlength="80" required><?php if (isset($erros['cidade'])): ?><span class="err"><?= e($erros['cidade']) ?></span><?php endif; ?></label>
    <label class="field <?= isset($erros['pais']) ? 'invalid' : '' ?>"><span>País</span>
      <input name="pais" value="<?= e($d['pais']) ?>" maxlength="80" required><?php if (isset($erros['pais'])): ?><span class="err"><?= e($erros['pais']) ?></span><?php endif; ?></label>
    <label class="field full <?= isset($erros['descricao']) ? 'invalid' : '' ?>"><span>Descrição</span>
      <textarea name="descricao" required minlength="20"><?= e($d['descricao']) ?></textarea><?php if (isset($erros['descricao'])): ?><span class="err"><?= e($erros['descricao']) ?></span><?php endif; ?></label>
    <label class="field full <?= isset($erros['imagem']) ? 'invalid' : '' ?>"><span>Imagem (JPG, PNG ou WEBP, até 2 MB)</span>
      <input type="file" name="imagem" accept="image/jpeg,image/png,image/webp"><?php if (isset($erros['imagem'])): ?><span class="err"><?= e($erros['imagem']) ?></span><?php endif; ?>
      <?php if ($d['imagem']): ?><img class="img-preview" src="<?= e(url($d['imagem'])) ?>" alt="Imagem atual de <?= e($d['cidade']) ?>"><span class="hint">Envie outra imagem para substituir a atual.</span><?php endif; ?></label>
  </div>
  <div class="form-actions"><a class="btn btn-ghost" href="<?= url('destinos/index.php') ?>">Cancelar</a>
    <button class="btn btn-primary" type="submit"><?= $id ? 'Salvar alterações' : 'Cadastrar destino' ?></button></div>
</form>
<?php require __DIR__ . '/../includes/footer.php'; ?>
