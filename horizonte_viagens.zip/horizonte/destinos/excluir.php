<?php
require_once __DIR__ . '/../includes/init.php';
exigir_post();
$id = (int)($_POST['id'] ?? 0);

$s = db()->prepare('SELECT cidade, imagem FROM destinos WHERE id = ?'); $s->execute([$id]);
$d = $s->fetch();
if (!$d) { flash('error', 'Destino não encontrado.'); redirect('destinos/index.php'); }

$s = db()->prepare('SELECT COUNT(*) FROM pacotes WHERE destino_id = ?'); $s->execute([$id]);
if ((int)$s->fetchColumn() > 0) {
    flash('error', 'Não é possível excluir "' . $d['cidade'] . '": existem pacotes vinculados a este destino.');
    redirect('destinos/index.php');
}
try {
    db()->prepare('DELETE FROM destinos WHERE id = ?')->execute([$id]);
    remover_imagem($d['imagem']);
    registrar_historico('excluiu', 'destinos', $id, 'Destino "' . $d['cidade'] . '" excluído');
    flash('success', 'Destino excluído com sucesso.');
} catch (PDOException $e) {
    flash('error', 'Não foi possível excluir o destino.');
}
redirect('destinos/index.php');
