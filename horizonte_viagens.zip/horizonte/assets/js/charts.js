/* Gráficos em SVG puro (sem bibliotecas externas).
   Uso: <div class="chart" data-type="bar|donut" data-labels='[...]' data-values='[...]'
             data-format="money|int" data-colors='[...]'></div> */
(function () {
  'use strict';
  const PALETA = ['#0E8FA0', '#F2994A', '#0B3C5D', '#7BD3C6', '#E5604D', '#9AA9B5'];
  const money = v => 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const compact = v => v >= 1000 ? 'R$ ' + (v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + 'k' : 'R$ ' + v;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function niceMax(m) {
    const p = Math.pow(10, Math.floor(Math.log10(m))), f = m / p;
    return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 4 ? 4 : f <= 8 ? 8 : 10) * p;
  }

  function bar(el) {
    const L = JSON.parse(el.dataset.labels), V = JSON.parse(el.dataset.values).map(Number);
    const isMoney = el.dataset.format === 'money', cor = el.dataset.color || PALETA[0];
    if (!V.length || V.every(v => v === 0)) { el.innerHTML = '<div class="chart-empty">Sem dados no período.</div>'; return; }
    const W = 600, H = 250, pl = isMoney ? 56 : 34, pr = 8, pt = 12, pb = 28;
    const mx = isMoney ? niceMax(Math.max(...V)) : Math.max(4, Math.ceil(Math.max(...V) / 4) * 4);
    let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(el.dataset.title || 'Gráfico de barras')}">`;
    for (let i = 0; i <= 4; i++) {
      const y = pt + (H - pt - pb) * (1 - i / 4), val = mx * i / 4;
      s += `<line class="grid" x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}"/>` +
           `<text class="axis" x="${pl - 6}" y="${y + 4}" text-anchor="end">${isMoney ? compact(val) : val}</text>`;
    }
    const bw = (W - pl - pr) / V.length;
    V.forEach((v, i) => {
      const h = (H - pt - pb) * v / mx, w = Math.min(bw * 0.62, 46), x = pl + i * bw + (bw - w) / 2, y = H - pb - h;
      s += `<rect class="bar" x="${x}" y="${y}" width="${w}" height="${Math.max(h, 0)}" rx="5" fill="${cor}"><title>${esc(L[i])}: ${isMoney ? money(v) : v}</title></rect>` +
           `<text class="axis" x="${x + w / 2}" y="${H - 9}" text-anchor="middle">${esc(L[i])}</text>`;
    });
    el.innerHTML = s + '</svg>';
  }

  function donut(el) {
    const L = JSON.parse(el.dataset.labels), V = JSON.parse(el.dataset.values).map(Number);
    const cores = el.dataset.colors ? JSON.parse(el.dataset.colors) : PALETA;
    const total = V.reduce((a, b) => a + b, 0);
    if (!total) { el.innerHTML = '<div class="chart-empty">Sem dados no período.</div>'; return; }
    const r = 60, c = 2 * Math.PI * r;
    let acc = 0, arcos = '', leg = '';
    V.forEach((v, i) => {
      const len = c * v / total, cor = cores[i % cores.length];
      if (v > 0) arcos += `<circle cx="90" cy="90" r="${r}" fill="none" stroke="${cor}" stroke-width="26" stroke-dasharray="${len} ${c - len}" stroke-dashoffset="${-acc}" transform="rotate(-90 90 90)"><title>${esc(L[i])}: ${v}</title></circle>`;
      acc += len;
      leg += `<li><i style="background:${cor}"></i>${esc(L[i])}<b>${v} (${Math.round(v * 100 / total)}%)</b></li>`;
    });
    el.innerHTML = `<div class="donut-wrap"><svg viewBox="0 0 180 180" role="img" aria-label="${esc(el.dataset.title || 'Gráfico de rosca')}">${arcos}` +
      `<text class="donut-center" x="90" y="92" text-anchor="middle">${total}</text><text class="donut-sub" x="90" y="108" text-anchor="middle">${esc(el.dataset.center || 'total')}</text></svg><ul class="legend">${leg}</ul></div>`;
  }

  document.querySelectorAll('.chart[data-type]').forEach(el => {
    try { (el.dataset.type === 'donut' ? donut : bar)(el); }
    catch (e) { el.innerHTML = '<div class="chart-empty">Não foi possível desenhar o gráfico.</div>'; }
  });
})();
