/* Horizonte Viagens - interações gerais */
(function () {
  'use strict';
  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  /* ----- Menu lateral (mobile) ----- */
  const toggle = $('#menuToggle'), scrim = $('#scrim');
  if (toggle) toggle.addEventListener('click', () => document.body.classList.toggle('menu-open'));
  if (scrim)  scrim.addEventListener('click', () => document.body.classList.remove('menu-open'));

  /* ----- Fechar alertas ----- */
  document.addEventListener('click', e => {
    const b = e.target.closest('.alert-close');
    if (b) b.parentElement.remove();
  });

  /* ----- Confirmação antes de excluir / cancelar ----- */
  const dlg = $('#confirmDialog');
  document.addEventListener('submit', e => {
    const form = e.target.closest('form[data-confirm]');
    if (!form || form.dataset.confirmed === '1' || !dlg) return;
    e.preventDefault();
    $('#confirmTitle').textContent = form.dataset.confirmTitle || 'Confirmar exclusão';
    $('#confirmText').textContent  = form.dataset.confirm;
    $('#confirmOk').textContent    = form.dataset.confirmBtn || 'Excluir';
    dlg.returnValue = '';
    dlg.showModal();
    dlg.addEventListener('close', function onClose() {
      dlg.removeEventListener('close', onClose);
      if (dlg.returnValue === 'ok') { form.dataset.confirmed = '1'; form.submit(); }
    });
  });

  /* ----- Pesquisa dinâmica e filtros (AJAX) ----- */
  $$('form[data-live]').forEach(form => {
    const alvo = $('#lista');
    if (!alvo) return;
    let timer;
    const carregar = url => fetch(url, { headers: { 'X-Requested-With': 'fetch' } })
      .then(r => r.text())
      .then(html => {
        const novo = new DOMParser().parseFromString(html, 'text/html').getElementById('lista');
        if (novo) { alvo.innerHTML = novo.innerHTML; history.replaceState(null, '', url); }
      });
    const executar = () => {
      const p = new URLSearchParams(new FormData(form));
      p.delete('pagina');
      carregar(form.action.split('?')[0] + '?' + p.toString());
    };
    form.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(executar, 280); });
    form.addEventListener('change', e => { if (e.target.tagName === 'SELECT' || e.target.type === 'date') executar(); });
    form.addEventListener('submit', e => { e.preventDefault(); executar(); });
    alvo.addEventListener('click', e => {
      const a = e.target.closest('.pager a.pg');
      if (a) { e.preventDefault(); carregar(a.href); }
    });
  });

  /* ----- Máscaras de CPF e telefone ----- */
  const mascara = {
    cpf: v => v.replace(/\D/g, '').slice(0, 11)
      .replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2'),
    tel: v => {
      v = v.replace(/\D/g, '').slice(0, 11);
      return v.length > 10 ? v.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3')
                           : v.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3').replace(/-$/, '');
    }
  };
  $$('input[data-mask]').forEach(i => {
    const f = mascara[i.dataset.mask];
    i.addEventListener('input', () => { i.value = f(i.value); });
    i.value = f(i.value);
  });

  /* ----- Validação no navegador (a validação real é feita no servidor) ----- */
  $$('form[data-validate]').forEach(form => {
    form.setAttribute('novalidate', '');
    form.addEventListener('submit', e => {
      let ok = true;
      $$('.field', form).forEach(f => {
        f.classList.remove('invalid');
        const old = $('.err', f); if (old) old.remove();
      });
      $$('input,select,textarea', form).forEach(c => {
        if (c.checkValidity()) return;
        ok = false;
        const f = c.closest('.field');
        if (f) {
          f.classList.add('invalid');
          const s = document.createElement('span');
          s.className = 'err';
          s.textContent = c.validity.valueMissing ? 'Preencha este campo.' : (c.title || 'Valor inválido.');
          f.appendChild(s);
        }
      });
      if (!ok) { e.preventDefault(); const p = $('.invalid input,.invalid select,.invalid textarea', form); if (p) p.focus(); }
    });
  });

  /* ----- Pacote: duração calculada pelas datas ----- */
  const ds = $('#data_saida'), dr = $('#data_retorno'), du = $('#duracao_dias');
  if (ds && dr && du) {
    const calc = () => {
      if (!ds.value || !dr.value) return;
      const d = Math.round((new Date(dr.value) - new Date(ds.value)) / 86400000) + 1;
      du.value = d > 0 ? d : '';
    };
    ds.addEventListener('change', calc); dr.addEventListener('change', calc); calc();
  }

  /* ----- Reserva: total e vagas em tempo real ----- */
  const sp = $('#pacote_id'), qp = $('#qtd_pessoas'), rs = $('#resumoReserva');
  if (sp && qp && rs) {
    const brl = v => 'R$ ' + v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const atualizar = () => {
      const o = sp.selectedOptions[0];
      if (!o || !o.dataset.preco) { rs.hidden = true; return; }
      const preco = parseFloat(o.dataset.preco), vagas = parseInt(o.dataset.vagas, 10), q = parseInt(qp.value, 10) || 0;
      rs.hidden = false;
      $('#rsPreco').textContent = brl(preco);
      $('#rsVagas').textContent = vagas + (q > vagas ? ' (insuficiente)' : '');
      $('#rsTotal').textContent = brl(preco * q);
      qp.max = vagas;
    };
    sp.addEventListener('change', atualizar); qp.addEventListener('input', atualizar); atualizar();
  }

  /* ----- Pagamento: mostra saldo da reserva e permite quitar ----- */
  const sr = $('#reserva_id'), vl = $('#valor'), sd = $('#resumoSaldo');
  if (sr && vl && sd) {
    const brl = v => 'R$ ' + v.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
    const atualizar = () => {
      const o = sr.selectedOptions[0];
      if (!o || !o.dataset.total) { sd.hidden = true; return; }
      sd.hidden = false;
      $('#spTotal').textContent = brl(parseFloat(o.dataset.total));
      $('#spPago').textContent  = brl(parseFloat(o.dataset.pago));
      $('#spSaldo').textContent = brl(parseFloat(o.dataset.saldo));
    };
    sr.addEventListener('change', atualizar); atualizar();
    const q = $('#btnQuitar');
    if (q) q.addEventListener('click', () => {
      const o = sr.selectedOptions[0];
      if (o && o.dataset.saldo) vl.value = parseFloat(o.dataset.saldo).toFixed(2);
    });
  }
})();
