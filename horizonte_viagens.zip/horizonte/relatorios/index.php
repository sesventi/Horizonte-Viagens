<?php
require_once __DIR__ . '/../includes/init.php';

$tipos = ['clientes' => 'Clientes cadastrados', 'viagens' => 'Viagens disponíveis', 'reservas' => 'Reservas', 'financeiro' => 'Financeiro'];
$tipo = array_key_exists(get('tipo'), $tipos) ? get('tipo') : 'reservas';
$de = get('de'); $ate = get('ate'); $sit = get('situacao'); $q = get('q');
if ($de  !== '' && !data_valida($de))  $de  = '';
if ($ate !== '' && !data_valida($ate)) $ate = '';

function consulta(string $sql, array $p = []): array { $s = db()->prepare($sql); $s->execute($p); return $s->fetchAll(); }

/* Cada relatório define: colunas, linhas, resumo e opções do filtro "situação" */
$cols = []; $linhas = []; $resumo = []; $opcoesSit = []; $rotuloPeriodo = 'Período'; $usaBusca = false;
$w = ['1=1']; $par = [];

switch ($tipo) {
case 'clientes':
    $rotuloPeriodo = 'Cadastro'; $usaBusca = true;
    if ($q !== '')  { $w[] = '(c.nome LIKE ? OR c.cpf LIKE ? OR c.email LIKE ?)'; array_push($par, "%$q%", '%' . (so_digitos($q) ?: $q) . '%', "%$q%"); }
    if ($de)  { $w[] = 'DATE(c.criado_em) >= ?'; $par[] = $de; }
    if ($ate) { $w[] = 'DATE(c.criado_em) <= ?'; $par[] = $ate; }
    $linhas = consulta("SELECT c.nome, c.cpf, c.telefone, c.email, c.endereco, c.criado_em, COUNT(r.id) AS reservas, COALESCE(SUM(r.valor_total), 0) AS total
        FROM clientes c LEFT JOIN reservas r ON r.cliente_id = c.id AND r.status <> 'cancelada'
        WHERE " . implode(' AND ', $w) . ' GROUP BY c.id, c.nome, c.cpf, c.telefone, c.email, c.endereco, c.criado_em ORDER BY c.nome', $par);
    $cols = [['nome', 'Nome', 'text'], ['cpf', 'CPF', 'cpf'], ['telefone', 'Telefone', 'text'], ['email', 'E-mail', 'text'], ['endereco', 'Endereço', 'text'],
             ['criado_em', 'Cadastro', 'date'], ['reservas', 'Reservas', 'int'], ['total', 'Total reservado', 'money']];
    $resumo = ['Clientes' => count($linhas), 'Reservas ativas' => array_sum(array_column($linhas, 'reservas')), 'Total reservado' => brl(array_sum(array_column($linhas, 'total')))];
    break;

case 'viagens':
    $rotuloPeriodo = 'Data de saída';
    $opcoesSit = ['disponivel' => 'Disponível', 'esgotado' => 'Esgotado', 'encerrado' => 'Encerrado', 'inativo' => 'Indisponível'];
    $f = ['disponivel' => 'ativo = 1 AND data_saida >= CURDATE() AND vagas_disponiveis > 0', 'esgotado' => 'ativo = 1 AND data_saida >= CURDATE() AND vagas_disponiveis <= 0',
          'encerrado' => 'ativo = 1 AND data_saida < CURDATE()', 'inativo' => 'ativo = 0'];
    if (isset($f[$sit])) $w[] = $f[$sit]; else $sit = '';
    if ($de)  { $w[] = 'data_saida >= ?'; $par[] = $de; }
    if ($ate) { $w[] = 'data_saida <= ?'; $par[] = $ate; }
    $linhas = consulta('SELECT * FROM vw_pacotes WHERE ' . implode(' AND ', $w) . ' ORDER BY data_saida', $par);
    foreach ($linhas as &$l) $l['situacao'] = pacote_situacao($l); unset($l);
    $cols = [['titulo', 'Pacote', 'text'], ['cidade', 'Cidade', 'text'], ['pais', 'País', 'text'], ['data_saida', 'Saída', 'date'], ['data_retorno', 'Retorno', 'date'],
             ['duracao_dias', 'Dias', 'int'], ['preco', 'Preço', 'money'], ['vagas_total', 'Vagas', 'int'], ['vagas_ocupadas', 'Ocupadas', 'int'], ['vagas_disponiveis', 'Livres', 'int'], ['situacao', 'Situação', 'badge']];
    $resumo = ['Pacotes' => count($linhas), 'Vagas totais' => array_sum(array_column($linhas, 'vagas_total')), 'Vagas livres' => array_sum(array_column($linhas, 'vagas_disponiveis'))];
    break;

case 'reservas':
    $rotuloPeriodo = 'Reserva criada'; $usaBusca = true;
    $opcoesSit = ['pendente' => 'Pendente', 'confirmada' => 'Confirmada', 'cancelada' => 'Cancelada'];
    if (isset($opcoesSit[$sit])) { $w[] = 'r.status = ?'; $par[] = $sit; } else $sit = '';
    if ($q !== '')  { $w[] = '(c.nome LIKE ? OR pk.titulo LIKE ? OR d.cidade LIKE ?)'; array_push($par, "%$q%", "%$q%", "%$q%"); }
    if ($de)  { $w[] = 'DATE(r.criado_em) >= ?'; $par[] = $de; }
    if ($ate) { $w[] = 'DATE(r.criado_em) <= ?'; $par[] = $ate; }
    $linhas = consulta('SELECT r.id, r.criado_em, c.nome AS cliente, pk.titulo, d.cidade, pk.data_saida, r.qtd_pessoas, r.valor_total, r.valor_pago, r.status, r.status_pagamento
        FROM reservas r JOIN clientes c ON c.id = r.cliente_id JOIN pacotes pk ON pk.id = r.pacote_id JOIN destinos d ON d.id = pk.destino_id
        WHERE ' . implode(' AND ', $w) . ' ORDER BY r.id', $par);
    $cols = [['id', 'Nº', 'int'], ['criado_em', 'Criada em', 'date'], ['cliente', 'Cliente', 'text'], ['titulo', 'Pacote', 'text'], ['cidade', 'Destino', 'text'],
             ['data_saida', 'Saída', 'date'], ['qtd_pessoas', 'Pessoas', 'int'], ['valor_total', 'Total', 'money'], ['valor_pago', 'Pago', 'money'], ['status', 'Reserva', 'badge'], ['status_pagamento', 'Pagamento', 'badge']];
    $ativas = array_filter($linhas, fn($l) => $l['status'] !== 'cancelada');
    $resumo = ['Reservas' => count($linhas), 'Pessoas (ativas)' => array_sum(array_column($ativas, 'qtd_pessoas')), 'Valor (ativas)' => brl(array_sum(array_column($ativas, 'valor_total')))];
    break;

case 'financeiro':
    $rotuloPeriodo = 'Reserva criada';
    $opcoesSit = ['pendente' => 'Pendente', 'parcial' => 'Parcialmente pago', 'pago' => 'Pago'];
    $w[] = "r.status <> 'cancelada'";
    if (isset($opcoesSit[$sit])) { $w[] = 'r.status_pagamento = ?'; $par[] = $sit; } else $sit = '';
    if ($de)  { $w[] = 'DATE(r.criado_em) >= ?'; $par[] = $de; }
    if ($ate) { $w[] = 'DATE(r.criado_em) <= ?'; $par[] = $ate; }
    $linhas = consulta('SELECT r.id, c.nome AS cliente, pk.titulo, r.valor_total, r.valor_pago, (r.valor_total - r.valor_pago) AS saldo, r.status_pagamento
        FROM reservas r JOIN clientes c ON c.id = r.cliente_id JOIN pacotes pk ON pk.id = r.pacote_id
        WHERE ' . implode(' AND ', $w) . ' ORDER BY r.id', $par);
    $cols = [['id', 'Reserva', 'int'], ['cliente', 'Cliente', 'text'], ['titulo', 'Pacote', 'text'], ['valor_total', 'Valor total', 'money'],
             ['valor_pago', 'Recebido', 'money'], ['saldo', 'Saldo a receber', 'money'], ['status_pagamento', 'Situação', 'badge']];
    $resumo = ['Faturamento previsto' => brl(array_sum(array_column($linhas, 'valor_total'))), 'Recebido' => brl(array_sum(array_column($linhas, 'valor_pago'))), 'A receber' => brl(array_sum(array_column($linhas, 'saldo')))];
    break;
}

/* Recebimentos por forma de pagamento (relatório financeiro) */
$porForma = [];
if ($tipo === 'financeiro') {
    $wp = ['1=1']; $pp = [];
    if ($de)  { $wp[] = 'data_pagamento >= ?'; $pp[] = $de; }
    if ($ate) { $wp[] = 'data_pagamento <= ?'; $pp[] = $ate; }
    $porForma = consulta('SELECT forma, COUNT(*) qtd, SUM(valor) total FROM pagamentos WHERE ' . implode(' AND ', $wp) . ' GROUP BY forma ORDER BY total DESC', $pp);
}

/* ----- Formatação de células ----- */
function celula($v, string $t): string
{
    switch ($t) {
        case 'money': return brl($v);
        case 'date':  return data_br($v);
        case 'cpf':   return e(fmt_cpf((string)$v));
        case 'badge': return badge((string)$v);
        default:      return e($v);
    }
}
function valor_csv($v, string $t): string
{
    switch ($t) {
        case 'money': return number_format((float)$v, 2, ',', '');
        case 'date':  return data_br($v);
        case 'cpf':   return fmt_cpf((string)$v);
        case 'badge': return rotulo_status((string)$v);
        default:      return (string)$v;
    }
}

/* ----- Exportação CSV (todas as linhas do filtro) ----- */
if (get('export') === 'csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="relatorio_' . $tipo . '_' . date('Ymd_His') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");                       // BOM para o Excel reconhecer acentos
    fputcsv($out, array_column($cols, 1), ';');
    foreach ($linhas as $l) fputcsv($out, array_map(fn($c) => valor_csv($l[$c[0]], $c[2]), $cols), ';');
    fclose($out);
    registrar_historico('criou', 'relatorios', null, 'Relatório "' . $tipos[$tipo] . '" exportado em CSV (' . count($linhas) . ' linhas)');
    exit;
}

/* ----- Paginação em tela (impressão mostra tudo) ----- */
$imprimir = get('imprimir') === '1';
$pg = paginar(count($linhas), 12);
$visiveis = $imprimir ? $linhas : array_slice($linhas, $pg['offset'], $pg['limite']);

$qs = fn(array $extra = []) => http_build_query(array_filter(array_merge(['tipo' => $tipo, 'de' => $de, 'ate' => $ate, 'situacao' => $sit, 'q' => $q], $extra), fn($v) => $v !== '' && $v !== null));

$titulo = 'Relatórios'; $menu = 'relatorios';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head no-print">
  <div><h2>Relatórios</h2><p>Filtre por período e situação e exporte em CSV ou PDF.</p></div>
  <div class="actions">
    <a class="btn btn-ghost" href="?<?= e($qs(['export' => 'csv'])) ?>"><?= icon('download', 18) ?> Exportar CSV</a>
    <a class="btn btn-primary" href="?<?= e($qs(['imprimir' => '1'])) ?>" target="_blank" rel="noopener"><?= icon('print', 18) ?> Exportar PDF</a>
  </div>
</div>

<nav class="tabs"><?php foreach ($tipos as $k => $r): ?><a class="tab <?= $k === $tipo ? 'on' : '' ?>" href="?tipo=<?= $k ?>"><?= e($r) ?></a><?php endforeach; ?></nav>

<div class="print-head"><h2><?= e(APP_NAME) ?> - <?= e($tipos[$tipo]) ?></h2>
  <small>Emitido em <?= date('d/m/Y H:i') ?><?= $de ? ' | de ' . data_br($de) : '' ?><?= $ate ? ' até ' . data_br($ate) : '' ?><?= $sit && isset($opcoesSit[$sit]) ? ' | situação: ' . e($opcoesSit[$sit]) : '' ?></small></div>

<section class="kpis" style="margin-bottom:18px">
<?php foreach ($resumo as $rot => $val): ?>
  <div class="card kpi"><div><small><?= e($rot) ?></small><strong><?= e($val) ?></strong></div></div>
<?php endforeach; ?>
</section>

<div class="card">
  <form method="get" class="filters">
    <input type="hidden" name="tipo" value="<?= e($tipo) ?>">
    <?php if ($usaBusca): ?><label class="field grow search"><span>Pesquisar</span><?= icon('search', 18) ?><input type="search" name="q" value="<?= e($q) ?>" placeholder="Nome, e-mail, pacote..."></label><?php endif; ?>
    <label class="field"><span><?= e($rotuloPeriodo) ?> de</span><input type="date" name="de" value="<?= e($de) ?>"></label>
    <label class="field"><span>até</span><input type="date" name="ate" value="<?= e($ate) ?>"></label>
    <?php if ($opcoesSit): ?><label class="field"><span>Situação</span><select name="situacao"><option value="">Todas</option>
      <?php foreach ($opcoesSit as $k => $r): ?><option value="<?= $k ?>" <?= $sit === $k ? 'selected' : '' ?>><?= e($r) ?></option><?php endforeach; ?></select></label><?php endif; ?>
    <button class="btn btn-primary" type="submit"><?= icon('filter', 16) ?> Aplicar filtros</button>
    <a class="btn btn-ghost" href="?tipo=<?= e($tipo) ?>">Limpar</a>
  </form>

  <?php if (!$linhas): ?>
    <div class="empty"><strong>Nenhum registro encontrado</strong>Altere o período ou a situação para ver resultados.</div>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><?php foreach ($cols as $c): ?><th class="<?= in_array($c[2], ['money', 'int']) ? 'num' : '' ?>"><?= e($c[1]) ?></th><?php endforeach; ?></tr></thead>
    <tbody><?php foreach ($visiveis as $l): ?><tr>
      <?php foreach ($cols as $c): ?><td class="<?= in_array($c[2], ['money', 'int']) ? 'num' : '' ?>"><?= celula($l[$c[0]], $c[2]) ?></td><?php endforeach; ?>
    </tr><?php endforeach; ?></tbody>
  </table></div>
  <?php if (!$imprimir) echo paginacao_html($pg); ?>
  <?php endif; ?>
</div>

<?php if ($porForma): ?>
<div class="card" style="margin-top:18px"><div class="card-head"><h3>Recebimentos por forma de pagamento</h3></div>
  <div class="table-wrap"><table><thead><tr><th>Forma</th><th class="num">Pagamentos</th><th class="num">Total recebido</th></tr></thead><tbody>
  <?php $fp = formas_pagamento(); foreach ($porForma as $f): ?><tr><td><?= e($fp[$f['forma']] ?? $f['forma']) ?></td><td class="num"><?= (int)$f['qtd'] ?></td><td class="num"><?= brl($f['total']) ?></td></tr><?php endforeach; ?>
  </tbody></table></div></div>
<?php endif; ?>
<?php if ($imprimir): ?><script>window.addEventListener('load', function () { window.print(); });</script><?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
