<?php
require_once __DIR__ . '/../includes/init.php';
exigir_post();
$id = (int)($_POST['id'] ?? 0);

$s = db()->prepare('SELECT status, qtd_pessoas, valor_pago FROM reservas WHERE id = ?'); $s->execute([$id]);
$r = $s->fetch();
if (!$r)                          { flash('error', 'Reserva não encontrada.'); redirect('reservas/index.php'); }
if ($r['status'] === 'cancelada') { flash('error', 'Esta reserva já está cancelada.'); redirect('reservas/index.php'); }

db()->prepare("UPDATE reservas SET status = 'cancelada' WHERE id = ?")->execute([$id]);
registrar_historico('cancelou', 'reservas', $id, 'Reserva #' . $id . ' cancelada - ' . $r['qtd_pessoas'] . ' vaga(s) liberada(s)');
$msg = 'Reserva #' . $id . ' cancelada. ' . $r['qtd_pessoas'] . ' vaga(s) liberada(s) automaticamente.';
if ((float)$r['valor_pago'] > 0) $msg .= ' Atenção: há ' . brl($r['valor_pago']) . ' pagos nesta reserva; trate o estorno com o cliente.';
flash('success', $msg);
redirect('reservas/index.php');
