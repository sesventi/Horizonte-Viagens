<?php
require_once __DIR__ . '/../includes/init.php';
$pdo = db();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$r = ['cliente_id' => (int)($_GET['cliente_id'] ?? 0), 'pacote_id' => (int)($_GET['pacote_id'] ?? 0), 'qtd_pessoas' => 1,
      'status' => 'pendente', 'observacoes' => '', 'valor_total' => 0, 'valor_pago' => 0];
if ($id) {
    $s = $pdo->prepare('SELECT * FROM reservas WHERE id = ?'); $s->execute([$id]);
    $r = $s->fetch();
    if (!$r) { flash('error', 'Reserva não encontrada.'); redirect('reservas/index.php'); }
    if ($r['status'] === 'cancelada') { flash('error', 'Reservas canceladas não podem ser alteradas.'); redirect('reservas/index.php'); }
}
$orig = $r;

$erros = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $r['cliente_id']  = (int)post('cliente_id');
    $r['pacote_id']   = (int)post('pacote_id');
    $r['qtd_pessoas'] = (int)post('qtd_pessoas');
    $r['status']      = post('status');
    $r['observacoes'] = post('observacoes');

    $s = $pdo->prepare('SELECT COUNT(*) FROM clientes WHERE id = ?'); $s->execute([$r['cliente_id']]);
    if (!$s->fetchColumn()) $erros['cliente_id'] = 'Selecione um cliente.';
    if ($r['qtd_pessoas'] < 1 || $r['qtd_pessoas'] > 100) $erros['qtd_pessoas'] = 'Informe uma quantidade de pessoas entre 1 e 100.';
    if (!in_array($r['status'], ['pendente', 'confirmada'], true)) $r['status'] = 'pendente';
    if (mb_strlen($r['observacoes']) > 255) $erros['observacoes'] = 'Máximo de 255 caracteres.';

    if (!$erros) {
        try {
            $pdo->beginTransaction();
            // Trava a linha do pacote para evitar overbooking com reservas simultâneas
            $s = $pdo->prepare('SELECT preco, ativo, data_saida, titulo FROM pacotes WHERE id = ? FOR UPDATE');
            $s->execute([$r['pacote_id']]);
            $pk = $s->fetch();
            if (!$pk) throw new RuntimeException('pacote_id|Selecione um pacote.');

            $mudouPacote = !$id || (int)$orig['pacote_id'] !== $r['pacote_id'];
            if ($mudouPacote && (!$pk['ativo'] || $pk['data_saida'] < date('Y-m-d')))
                throw new RuntimeException('pacote_id|Este pacote não está disponível para reservas.');

            $livres = vagas_disponiveis($r['pacote_id'], $id);   // ignora a própria reserva ao editar
            if ($r['qtd_pessoas'] > $livres)
                throw new RuntimeException('qtd_pessoas|Vagas insuficientes: restam apenas ' . max(0, $livres) . ' neste pacote.');

            // Edição sem troca de pacote preserva o preço unitário da época da reserva
            $unit  = (!$mudouPacote && $orig['qtd_pessoas'] > 0) ? $orig['valor_total'] / $orig['qtd_pessoas'] : (float)$pk['preco'];
            $total = round($unit * $r['qtd_pessoas'], 2);
            if ($id && $total < (float)$orig['valor_pago'])
                throw new RuntimeException('geral|O novo valor total (' . brl($total) . ') é menor que o já pago (' . brl($orig['valor_pago']) . ').');

            if ($id) {
                $pdo->prepare('UPDATE reservas SET cliente_id=?, pacote_id=?, qtd_pessoas=?, valor_total=?, status=?, observacoes=? WHERE id=?')
                    ->execute([$r['cliente_id'], $r['pacote_id'], $r['qtd_pessoas'], $total, $r['status'], $r['observacoes'] ?: null, $id]);
                $rid = $id;
            } else {
                $pdo->prepare('INSERT INTO reservas (cliente_id, pacote_id, qtd_pessoas, valor_total, status, observacoes) VALUES (?,?,?,?,?,?)')
                    ->execute([$r['cliente_id'], $r['pacote_id'], $r['qtd_pessoas'], $total, $r['status'], $r['observacoes'] ?: null]);
                $rid = (int)$pdo->lastInsertId();
            }
            atualizar_financeiro($rid);
            registrar_historico($id ? 'editou' : 'criou', 'reservas', $rid,
                'Reserva #' . $rid . ($id ? ' alterada' : ' criada') . ' - ' . $pk['titulo'] . ' (' . $r['qtd_pessoas'] . ' pessoa(s), ' . brl($total) . ')');
            $pdo->commit();
            flash('success', $id ? 'Reserva atualizada com sucesso.' : 'Reserva registrada com sucesso. Vagas atualizadas.');
            redirect('reservas/index.php');
        } catch (RuntimeException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            [$campo, $msg] = array_pad(explode('|', $ex->getMessage(), 2), 2, '');
            $erros[$campo ?: 'geral'] = $msg ?: 'Erro ao salvar.';
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $erros['geral'] = 'Não foi possível salvar a reserva.';
        }
    }
}

$clientes = $pdo->query('SELECT id, nome, cpf FROM clientes ORDER BY nome')->fetchAll();
$s = $pdo->prepare("SELECT * FROM vw_pacotes WHERE (ativo = 1 AND data_saida >= CURDATE() AND vagas_disponiveis > 0) OR id = ? ORDER BY data_saida");
$s->execute([(int)($orig['pacote_id'] ?? 0)]);
$pacotes = $s->fetchAll();

$titulo = $id ? 'Alterar reserva #' . $id : 'Nova reserva'; $menu = 'reservas';
require __DIR__ . '/../includes/header.php';
$err = fn(string $c) => isset($erros[$c]) ? '<span class="err">' . e($erros[$c]) . '</span>' : '';
$inv = fn(string $c) => isset($erros[$c]) ? ' invalid' : '';
?>
<div class="page-head"><div><h2><?= e($titulo) ?></h2><p>Vincule o cliente a um pacote com vagas disponíveis.</p></div>
  <a class="btn btn-ghost" href="<?= url('reservas/index.php') ?>">Voltar</a></div>

<form method="post" class="card form-card" data-validate>
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
  <?php if (isset($erros['geral'])): ?><div class="alert alert-error"><?= icon('alert', 18) ?><span><?= e($erros['geral']) ?></span></div><?php endif; ?>
  <div class="form-grid">
    <label class="field<?= $inv('cliente_id') ?> full"><span>Cliente</span><select name="cliente_id" required><option value="">Selecione...</option>
      <?php foreach ($clientes as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$r['cliente_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['nome']) ?> - <?= e(fmt_cpf($c['cpf'])) ?></option><?php endforeach; ?></select><?= $err('cliente_id') ?></label>
    <label class="field<?= $inv('pacote_id') ?> full"><span>Pacote</span><select name="pacote_id" id="pacote_id" required><option value="">Selecione...</option>
      <?php foreach ($pacotes as $p):
        $vagas = (int)$p['vagas_disponiveis'] + ($id && (int)$p['id'] === (int)$orig['pacote_id'] ? (int)$orig['qtd_pessoas'] : 0); ?>
        <option value="<?= (int)$p['id'] ?>" data-preco="<?= e($id && (int)$p['id'] === (int)$orig['pacote_id'] && $orig['qtd_pessoas'] > 0 ? $orig['valor_total'] / $orig['qtd_pessoas'] : $p['preco']) ?>" data-vagas="<?= $vagas ?>"
          <?= (int)$r['pacote_id'] === (int)$p['id'] ? 'selected' : '' ?>><?= e($p['titulo']) ?> - saída <?= data_br($p['data_saida']) ?> (<?= $vagas ?> vagas)</option><?php endforeach; ?></select><?= $err('pacote_id') ?></label>
    <label class="field<?= $inv('qtd_pessoas') ?>"><span>Quantidade de pessoas</span><input type="number" id="qtd_pessoas" name="qtd_pessoas" min="1" value="<?= (int)$r['qtd_pessoas'] ?>" required><?= $err('qtd_pessoas') ?></label>
    <label class="field"><span>Situação da reserva</span><select name="status">
      <option value="pendente" <?= $r['status'] === 'pendente' ? 'selected' : '' ?>>Pendente</option>
      <option value="confirmada" <?= $r['status'] === 'confirmada' ? 'selected' : '' ?>>Confirmada</option></select>
      <span class="hint">Passa a Confirmada automaticamente ao receber o primeiro pagamento.</span></label>
    <div class="full resumo" id="resumoReserva" hidden>
      <div><small>Preço por pessoa</small><strong id="rsPreco">-</strong></div>
      <div><small>Vagas livres</small><strong id="rsVagas">-</strong></div>
      <div><small>Valor total</small><strong id="rsTotal">-</strong></div>
    </div>
    <label class="field<?= $inv('observacoes') ?> full"><span>Observações (opcional)</span><textarea name="observacoes" maxlength="255" style="min-height:70px"><?= e($r['observacoes']) ?></textarea><?= $err('observacoes') ?></label>
  </div>
  <div class="form-actions"><a class="btn btn-ghost" href="<?= url('reservas/index.php') ?>">Cancelar</a>
    <button class="btn btn-primary" type="submit"><?= $id ? 'Salvar alterações' : 'Registrar reserva' ?></button></div>
</form>
<?php require __DIR__ . '/../includes/footer.php'; ?>
