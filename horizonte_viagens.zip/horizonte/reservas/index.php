<?php
require_once __DIR__ . '/../includes/init.php';

$q = get('q'); $st = get('status'); $sp = get('situacao_pg'); $pac = (int)get('pacote'); $de = get('de'); $ate = get('ate');
$where = ['1=1']; $params = [];
if ($q !== '') {
    $where[] = '(c.nome LIKE ? OR c.cpf LIKE ? OR pk.titulo LIKE ? OR d.cidade LIKE ? OR CAST(r.id AS CHAR) = ?)';
    $dig = so_digitos($q);
    array_push($params, "%$q%", $dig !== '' ? "%$dig%" : "%$q%", "%$q%", "%$q%", ltrim($q, '#'));
}
if (in_array($st, ['pendente', 'confirmada', 'cancelada'], true)) { $where[] = 'r.status = ?'; $params[] = $st; }
if (in_array($sp, ['pendente', 'parcial', 'pago'], true))          { $where[] = 'r.status_pagamento = ?'; $params[] = $sp; }
if ($pac > 0) { $where[] = 'r.pacote_id = ?'; $params[] = $pac; }
if ($de  !== '' && data_valida($de))  { $where[] = 'DATE(r.criado_em) >= ?'; $params[] = $de; }
if ($ate !== '' && data_valida($ate)) { $where[] = 'DATE(r.criado_em) <= ?'; $params[] = $ate; }
$sqlWhere = implode(' AND ', $where);
$from = 'FROM reservas r JOIN clientes c ON c.id = r.cliente_id JOIN pacotes pk ON pk.id = r.pacote_id JOIN destinos d ON d.id = pk.destino_id';

$s = db()->prepare("SELECT COUNT(*) $from WHERE $sqlWhere"); $s->execute($params);
$pg = paginar((int)$s->fetchColumn());
$s = db()->prepare("SELECT r.*, c.nome AS cliente_nome, pk.titulo, pk.data_saida, d.cidade $from WHERE $sqlWhere ORDER BY r.id DESC LIMIT {$pg['limite']} OFFSET {$pg['offset']}");
$s->execute($params);
$reservas = $s->fetchAll();
$listaPacotes = db()->query('SELECT id, titulo FROM pacotes ORDER BY data_saida DESC')->fetchAll();

$titulo = 'Reservas'; $menu = 'reservas';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <div><h2>Reservas</h2><p>Vagas e situação financeira são atualizadas automaticamente.</p></div>
  <a class="btn btn-primary" href="<?= url('reservas/form.php') ?>"><?= icon('plus', 18) ?> Nova reserva</a>
</div>

<div class="card">
  <form class="filters" data-live method="get" action="<?= url('reservas/index.php') ?>">
    <label class="field grow search"><span>Pesquisar</span><?= icon('search', 18) ?>
      <input type="search" name="q" value="<?= e($q) ?>" placeholder="Cliente, CPF, pacote, cidade ou nº da reserva"></label>
    <label class="field"><span>Reserva</span><select name="status"><option value="">Todas</option>
      <?php foreach (['pendente' => 'Pendente', 'confirmada' => 'Confirmada', 'cancelada' => 'Cancelada'] as $k => $r): ?><option value="<?= $k ?>" <?= $st === $k ? 'selected' : '' ?>><?= $r ?></option><?php endforeach; ?></select></label>
    <label class="field"><span>Pagamento</span><select name="situacao_pg"><option value="">Todos</option>
      <?php foreach (['pendente' => 'Pendente', 'parcial' => 'Parcial', 'pago' => 'Pago'] as $k => $r): ?><option value="<?= $k ?>" <?= $sp === $k ? 'selected' : '' ?>><?= $r ?></option><?php endforeach; ?></select></label>
    <label class="field"><span>Pacote</span><select name="pacote"><option value="">Todos</option>
      <?php foreach ($listaPacotes as $p): ?><option value="<?= (int)$p['id'] ?>" <?= $pac === (int)$p['id'] ? 'selected' : '' ?>><?= e($p['titulo']) ?></option><?php endforeach; ?></select></label>
    <label class="field"><span>Criada de</span><input type="date" name="de" value="<?= e($de) ?>"></label>
    <label class="field"><span>até</span><input type="date" name="ate" value="<?= e($ate) ?>"></label>
  </form>

  <div id="lista">
  <?php if (!$reservas): ?>
    <div class="empty"><strong>Nenhuma reserva encontrada</strong>Altere os filtros ou registre uma nova reserva.</div>
  <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Nº</th><th>Cliente</th><th>Pacote</th><th class="num">Pessoas</th><th class="num">Total</th><th class="num">Pago</th><th>Reserva</th><th>Pagamento</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($reservas as $r): $cancelada = $r['status'] === 'cancelada'; ?>
        <tr>
          <td>#<?= (int)$r['id'] ?><small><?= data_br($r['criado_em']) ?></small></td>
          <td><strong><?= e($r['cliente_nome']) ?></strong></td>
          <td><?= e($r['titulo']) ?><small><?= e($r['cidade']) ?> &middot; saída <?= data_br($r['data_saida']) ?></small></td>
          <td class="num"><?= (int)$r['qtd_pessoas'] ?></td>
          <td class="num"><?= brl($r['valor_total']) ?></td>
          <td class="num"><?= brl($r['valor_pago']) ?></td>
          <td><?= badge($r['status']) ?></td>
          <td><?= $cancelada ? '<span class="muted">-</span>' : badge($r['status_pagamento']) ?></td>
          <td><div class="row-actions">
            <?php if (!$cancelada && $r['status_pagamento'] !== 'pago'): ?>
              <a class="icon-btn" title="Registrar pagamento" href="<?= url('pagamentos/form.php?reserva_id=' . $r['id']) ?>"><?= icon('dollar', 18) ?></a><?php endif; ?>
            <?php if (!$cancelada): ?>
              <a class="icon-btn" title="Alterar reserva" href="<?= url('reservas/form.php?id=' . $r['id']) ?>"><?= icon('edit', 18) ?></a>
              <form method="post" action="<?= url('reservas/cancelar.php') ?>" data-confirm="A reserva #<?= (int)$r['id'] ?> de <?= e($r['cliente_nome']) ?> será cancelada e as <?= (int)$r['qtd_pessoas'] ?> vaga(s) serão liberadas." data-confirm-title="Cancelar reserva" data-confirm-btn="Cancelar reserva">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="icon-btn danger" title="Cancelar reserva" type="submit"><?= icon('ban', 18) ?></button></form>
            <?php endif; ?>
            <form method="post" action="<?= url('reservas/excluir.php') ?>" data-confirm="A reserva #<?= (int)$r['id'] ?> será excluída permanentemente. Deseja continuar?">
              <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="icon-btn danger" title="Excluir" type="submit"><?= icon('trash', 18) ?></button></form>
          </div></td>
        </tr>
      <?php endforeach; ?>
      </tbody></table></div>
  <?php endif; ?>
  <?= paginacao_html($pg) ?>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
