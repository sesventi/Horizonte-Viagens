<?php
require_once __DIR__ . '/../includes/init.php';
exigir_post();
$id = (int)($_POST['id'] ?? 0);

$s = db()->prepare('SELECT COUNT(*) FROM reservas WHERE id = ?'); $s->execute([$id]);
if (!$s->fetchColumn()) { flash('error', 'Reserva não encontrada.'); redirect('reservas/index.php'); }

$s = db()->prepare('SELECT COUNT(*) FROM pagamentos WHERE reserva_id = ?'); $s->execute([$id]);
if ((int)$s->fetchColumn() > 0) {
    flash('error', 'Não é possível excluir a reserva #' . $id . ': há pagamentos registrados. Use "Cancelar reserva" para liberar as vagas.');
    redirect('reservas/index.php');
}
try {
    db()->prepare('DELETE FROM reservas WHERE id = ?')->execute([$id]);
    registrar_historico('excluiu', 'reservas', $id, 'Reserva #' . $id . ' excluída');
    flash('success', 'Reserva excluída com sucesso. Vagas liberadas.');
} catch (PDOException $e) {
    flash('error', 'Não foi possível excluir a reserva.');
}
redirect('reservas/index.php');
