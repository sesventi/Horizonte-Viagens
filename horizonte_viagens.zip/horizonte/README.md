# Horizonte Viagens — Sistema de gestão para agência de turismo

Projeto da avaliação P2 de **Desenvolvimento Web II** (FATEC Itaquera).
Stack: **PHP 8 (PDO) · MySQL/MariaDB · HTML5 · CSS3 · JavaScript puro** (sem frameworks e sem bibliotecas externas de gráficos).

## Instalação no XAMPP (Windows)

1. Instale o XAMPP com **PHP 8.0 ou superior** e abra o *XAMPP Control Panel*. Inicie **Apache** e **MySQL**.
2. Copie a pasta `horizonte` para `C:\xampp\htdocs\`.
3. Acesse `http://localhost/phpmyadmin` → aba **Importar** → escolha `database/horizonte_viagens.sql` → **Executar**.
   (o script cria o banco `horizonte_viagens`, as tabelas, a view e os dados de teste).
4. Abra `http://localhost/horizonte/` no navegador.
5. Se o seu MySQL tiver senha no usuário `root`, ajuste `config/config.php` (`DB_USER` / `DB_PASS`).

### Acesso de demonstração
| Usuário | Senha | Perfil |
|---|---|---|
| `admin` | `admin123` | Administrador |
| `atendente` | `admin123` | Atendente |

## Estrutura de pastas
```
horizonte/
├── index.php  login.php  logout.php  dashboard.php
├── config/        config.php (credenciais) · database.php (conexão PDO reutilizável)
├── includes/      init.php · functions.php · header.php · footer.php · icons.php
├── assets/        css/style.css · js/app.js · js/charts.js · images/ · uploads/
├── clientes/      index · form · excluir
├── destinos/      index · form · excluir
├── pacotes/       index · form · excluir
├── reservas/      index · form · cancelar · excluir
├── pagamentos/    index · form · excluir
├── relatorios/    index (4 relatórios, CSV e PDF)
├── historico/     index (auditoria)
└── database/      horizonte_viagens.sql
```

## Como cada requisito foi atendido
| Requisito | Onde / como |
|---|---|
| Dashboard | `dashboard.php` — KPIs, 4 gráficos em SVG, melhores clientes, próximas saídas, pendências; filtro por período |
| CRUD de clientes (nome, CPF, telefone, e-mail, endereço) | `clientes/` — CPF validado por dígito verificador, CPF e e-mail únicos, máscaras |
| Destinos (cidade, país, descrição, imagem) | `destinos/` — upload validado (JPG/PNG/WEBP, 2 MB) |
| Pacotes (destino, preço, duração, vagas, datas, disponibilidade) | `pacotes/` — duração calculada pelas datas |
| Reservas (cliente + pacote, alterar, cancelar, situação) | `reservas/` |
| Pagamentos (valor, data, forma, pendente/parcial/pago) | `pagamentos/` |
| Relatórios (clientes, viagens, reservas, financeiro) | `relatorios/` — filtros por período e situação |
| Login/logout com sessão | `login.php`, `logout.php`, `includes/init.php` (todas as páginas exigem login) |
| Segurança | PDO com consultas preparadas, `password_hash`/`password_verify`, token CSRF em todo POST, escape de saída, `session_regenerate_id` |

### Diferenciais (todos funcionais)
- **Pesquisa dinâmica / filtros avançados:** busca e filtros atualizam a tabela via `fetch` (AJAX) enquanto você digita.
- **Paginação** em todas as listagens e relatórios.
- **Gráficos estatísticos** desenhados em SVG por `assets/js/charts.js`.
- **Controle automático de vagas:** vagas livres = total − reservas não canceladas (view `vw_pacotes`). A reserva é gravada dentro de uma transação com `SELECT ... FOR UPDATE`, impedindo *overbooking*. Cancelar/excluir uma reserva libera as vagas.
- **Situação financeira automática:** a cada pagamento incluído, alterado ou excluído, `atualizar_financeiro()` recalcula o valor pago e a situação (pendente → parcial → pago); o primeiro pagamento confirma a reserva. Pagamento acima do saldo é bloqueado.
- **Histórico de alterações:** toda criação, edição, exclusão, cancelamento, login e exportação fica registrada em `historico/`.
- **Exportação:** **CSV** (separador `;`, abre direto no Excel) e **PDF** (abre a versão de impressão do relatório; na janela de impressão escolha *Salvar como PDF*).
- **Confirmação antes de excluir/cancelar** com janela modal.

## Regras de integridade (banco)
Chaves primárias e estrangeiras (`ON DELETE RESTRICT`), `UNIQUE` (CPF, e-mail, usuário, destino), `CHECK` (preço > 0, vagas > 0, retorno ≥ saída, quantidade > 0, valor do pagamento > 0) e `ENUM` para situações. Clientes, destinos e pacotes com vínculos não podem ser excluídos (o sistema explica o motivo).

## Roteiro rápido para a apresentação
1. Entrar com `admin / admin123` e mostrar o dashboard (use o filtro de período).
2. **Pacotes** → o pacote "Réveillon no Rio" está **esgotado** (4/4 vagas).
3. **Reservas** → cancelar uma reserva e ver as vagas voltarem em **Pacotes**.
4. **Pagamentos** → registrar um pagamento parcial e depois quitar; observar a situação mudar em **Reservas**.
5. **Relatórios** → filtrar por período, exportar CSV e PDF.
6. **Histórico** → mostrar o registro de todas as ações feitas.
