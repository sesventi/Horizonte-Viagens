<?php
require_once __DIR__ . '/includes/init.php';
redirect('dashboard.php');
