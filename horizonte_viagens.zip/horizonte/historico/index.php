<?php
require_once __DIR__ . '/../includes/init.php';

$q = get('q'); $tab = get('tabela'); $acao = get('acao'); $de = get('de'); $ate = get('ate');
$where = ['1=1']; $params = [];
if ($q !== '')   { $where[] = '(h.detalhes LIKE ? OR h.usuario_nome LIKE ?)'; array_push($params, "%$q%", "%$q%"); }
if ($tab !== '') { $where[] = 'h.tabela = ?'; $params[] = $tab; }
if (in_array($acao, ['criou', 'editou', 'excluiu', 'cancelou', 'login', 'logout'], true)) { $where[] = 'h.acao = ?'; $params[] = $acao; }
if ($de  !== '' && data_valida($de))  { $where[] = 'DATE(h.criado_em) >= ?'; $params[] = $de; }
if ($ate !== '' && data_valida($ate)) { $where[] = 'DATE(h.criado_em) <= ?'; $params[] = $ate; }
$sqlWhere = implode(' AND ', $where);

$s = db()->prepare("SELECT COUNT(*) FROM historico h WHERE $sqlWhere"); $s->execute($params);
$pg = paginar((int)$s->fetchColumn(), 12);
$s = db()->prepare("SELECT h.* FROM historico h WHERE $sqlWhere ORDER BY h.id DESC LIMIT {$pg['limite']} OFFSET {$pg['offset']}");
$s->execute($params);
$registros = $s->fetchAll();
$tabelas = db()->query('SELECT DISTINCT tabela FROM historico ORDER BY tabela')->fetchAll(PDO::FETCH_COLUMN);
$cores = ['criou' => 'confirmada', 'editou' => 'parcial', 'excluiu' => 'cancelada', 'cancelou' => 'cancelada', 'login' => 'ativo', 'logout' => 'esgotado'];

$titulo = 'Histórico de alterações'; $menu = 'historico';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><div><h2>Histórico de alterações</h2><p>Registro de quem criou, editou, excluiu ou cancelou informações no sistema.</p></div></div>

<div class="card">
  <form class="filters" data-live method="get" action="<?= url('historico/index.php') ?>">
    <label class="field grow search"><span>Pesquisar</span><?= icon('search', 18) ?>
      <input type="search" name="q" value="<?= e($q) ?>" placeholder="Usuário ou descrição"></label>
    <label class="field"><span>Módulo</span><select name="tabela"><option value="">Todos</option>
      <?php foreach ($tabelas as $t): ?><option <?= $tab === $t ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select></label>
    <label class="field"><span>Ação</span><select name="acao"><option value="">Todas</option>
      <?php foreach (['criou', 'editou', 'excluiu', 'cancelou', 'login', 'logout'] as $a): ?><option value="<?= $a ?>" <?= $acao === $a ? 'selected' : '' ?>><?= ucfirst($a) ?></option><?php endforeach; ?></select></label>
    <label class="field"><span>De</span><input type="date" name="de" value="<?= e($de) ?>"></label>
    <label class="field"><span>até</span><input type="date" name="ate" value="<?= e($ate) ?>"></label>
  </form>

  <div id="lista">
  <?php if (!$registros): ?>
    <div class="empty"><strong>Nenhum registro encontrado</strong>Ajuste os filtros.</div>
  <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Data e hora</th><th>Usuário</th><th>Ação</th><th>Módulo</th><th>Detalhes</th></tr></thead>
      <tbody><?php foreach ($registros as $h): ?><tr>
        <td><?= datahora_br($h['criado_em']) ?></td>
        <td><?= e($h['usuario_nome']) ?></td>
        <td><span class="badge badge-<?= e($cores[$h['acao']] ?? 'esgotado') ?>"><?= e(ucfirst($h['acao'])) ?></span></td>
        <td><?= e(ucfirst($h['tabela'])) ?><?= $h['registro_id'] ? ' <small>#' . (int)$h['registro_id'] . '</small>' : '' ?></td>
        <td><?= e($h['detalhes']) ?></td></tr><?php endforeach; ?></tbody></table></div>
  <?php endif; ?>
  <?= paginacao_html($pg) ?>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
