-- =====================================================================
--  Horizonte Viagens - Sistema de gestão de agência de turismo
--  Banco de dados MySQL / MariaDB (XAMPP)  |  Importe pelo phpMyAdmin
-- =====================================================================
CREATE DATABASE IF NOT EXISTS horizonte_viagens
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE horizonte_viagens;

SET FOREIGN_KEY_CHECKS = 0;
DROP VIEW  IF EXISTS vw_pacotes;
DROP TABLE IF EXISTS historico, pagamentos, reservas, pacotes, destinos, clientes, usuarios;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- USUÁRIOS (controle de acesso)
-- ---------------------------------------------------------------------
CREATE TABLE usuarios (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(100) NOT NULL,
  usuario     VARCHAR(40)  NOT NULL UNIQUE,
  senha_hash  VARCHAR(255) NOT NULL,
  perfil      ENUM('admin','atendente') NOT NULL DEFAULT 'atendente',
  ativo       TINYINT(1)   NOT NULL DEFAULT 1,
  criado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- CLIENTES
-- ---------------------------------------------------------------------
CREATE TABLE clientes (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(120) NOT NULL,
  cpf           CHAR(11)     NOT NULL UNIQUE,
  telefone      VARCHAR(20)  NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  endereco      VARCHAR(255) NOT NULL,
  criado_em     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- DESTINOS
-- ---------------------------------------------------------------------
CREATE TABLE destinos (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cidade     VARCHAR(80)  NOT NULL,
  pais       VARCHAR(80)  NOT NULL,
  descricao  TEXT         NOT NULL,
  imagem     VARCHAR(255) NULL,
  criado_em  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_destino (cidade, pais)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- PACOTES TURÍSTICOS
-- ---------------------------------------------------------------------
CREATE TABLE pacotes (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  destino_id    INT UNSIGNED  NOT NULL,
  titulo        VARCHAR(120)  NOT NULL,
  preco         DECIMAL(10,2) NOT NULL,
  duracao_dias  SMALLINT UNSIGNED NOT NULL,
  vagas_total   SMALLINT UNSIGNED NOT NULL,
  data_saida    DATE NOT NULL,
  data_retorno  DATE NOT NULL,
  ativo         TINYINT(1) NOT NULL DEFAULT 1,
  criado_em     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pacote_destino FOREIGN KEY (destino_id) REFERENCES destinos(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT ck_pacote_preco  CHECK (preco > 0),
  CONSTRAINT ck_pacote_vagas  CHECK (vagas_total > 0),
  CONSTRAINT ck_pacote_datas  CHECK (data_retorno >= data_saida)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- RESERVAS
--   status            = situação da reserva (pendente/confirmada/cancelada)
--   status_pagamento  = situação financeira (calculada a partir dos pagamentos)
-- ---------------------------------------------------------------------
CREATE TABLE reservas (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cliente_id       INT UNSIGNED NOT NULL,
  pacote_id        INT UNSIGNED NOT NULL,
  qtd_pessoas      SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  valor_total      DECIMAL(10,2) NOT NULL DEFAULT 0,
  valor_pago       DECIMAL(10,2) NOT NULL DEFAULT 0,
  status           ENUM('pendente','confirmada','cancelada') NOT NULL DEFAULT 'pendente',
  status_pagamento ENUM('pendente','parcial','pago') NOT NULL DEFAULT 'pendente',
  observacoes      VARCHAR(255) NULL,
  criado_em        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_reserva_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_reserva_pacote  FOREIGN KEY (pacote_id)  REFERENCES pacotes(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT ck_reserva_qtd   CHECK (qtd_pessoas > 0),
  CONSTRAINT ck_reserva_valor CHECK (valor_total >= 0 AND valor_pago >= 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- PAGAMENTOS
-- ---------------------------------------------------------------------
CREATE TABLE pagamentos (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reserva_id      INT UNSIGNED  NOT NULL,
  valor           DECIMAL(10,2) NOT NULL,
  data_pagamento  DATE NOT NULL,
  forma           ENUM('pix','cartao_credito','cartao_debito','boleto','dinheiro','transferencia') NOT NULL,
  observacao      VARCHAR(255) NULL,
  criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pagamento_reserva FOREIGN KEY (reserva_id) REFERENCES reservas(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT ck_pagamento_valor CHECK (valor > 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- HISTÓRICO DE ALTERAÇÕES (auditoria)
-- ---------------------------------------------------------------------
CREATE TABLE historico (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id    INT UNSIGNED NULL,
  usuario_nome  VARCHAR(100) NOT NULL,
  acao          ENUM('criou','editou','excluiu','cancelou','login','logout') NOT NULL,
  tabela        VARCHAR(40)  NOT NULL,
  registro_id   INT UNSIGNED NULL,
  detalhes      VARCHAR(500) NULL,
  criado_em     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_hist_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  KEY idx_hist_data (criado_em)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- VIEW: pacotes com cálculo automático de vagas disponíveis
--   (reservas canceladas liberam as vagas)
-- ---------------------------------------------------------------------
CREATE VIEW vw_pacotes AS
SELECT p.id, p.destino_id, p.titulo, p.preco, p.duracao_dias, p.vagas_total,
       p.data_saida, p.data_retorno, p.ativo, p.criado_em,
       d.cidade, d.pais, d.imagem AS destino_imagem,
       COALESCE(o.ocupadas, 0)                    AS vagas_ocupadas,
       p.vagas_total - COALESCE(o.ocupadas, 0)    AS vagas_disponiveis
FROM pacotes p
JOIN destinos d ON d.id = p.destino_id
LEFT JOIN (SELECT pacote_id, SUM(qtd_pessoas) AS ocupadas
           FROM reservas WHERE status <> 'cancelada' GROUP BY pacote_id) o
       ON o.pacote_id = p.id;

-- =====================================================================
--  DADOS FICTÍCIOS PARA TESTE
-- =====================================================================
-- Senha dos usuários demo: admin123
INSERT INTO usuarios (nome, usuario, senha_hash, perfil) VALUES
('Administrador Horizonte',  'admin',     '$2y$12$6ITC9XjdPUiUgFjmk8ZVkuXSRDGj9j6B1y8TlovxXYF4emPFkyQ6.', 'admin'),
('Marina Costa (Atendente)', 'atendente', '$2y$12$6ITC9XjdPUiUgFjmk8ZVkuXSRDGj9j6B1y8TlovxXYF4emPFkyQ6.', 'atendente');

INSERT INTO clientes (nome, cpf, telefone, email, endereco, criado_em) VALUES
('Ana Beatriz Moura',     '52601815906', '(11) 98811-2034', 'ana.moura@email.com',       'Rua das Acácias, 120 - Itaquera, São Paulo/SP',    '2026-02-10 10:00:00'),
('Carlos Eduardo Lima',   '08301661305', '(11) 97722-5510', 'carlos.lima@email.com',     'Av. Radial Leste, 880 - Tatuapé, São Paulo/SP',    '2026-03-04 14:20:00'),
('Fernanda Ribeiro',      '18609139034', '(11) 96655-3321', 'fernanda.r@email.com',      'Rua Augusta, 455 - Consolação, São Paulo/SP',      '2026-03-18 09:15:00'),
('João Pedro Santos',     '99603082430', '(11) 95544-7788', 'joao.santos@email.com',     'Rua Vergueiro, 2300 - Vila Mariana, São Paulo/SP', '2026-04-02 16:40:00'),
('Luciana Almeida',       '62819482112', '(11) 94433-1290', 'luciana.almeida@email.com', 'Rua Tuiuti, 77 - Tatuapé, São Paulo/SP',            '2026-04-21 11:05:00'),
('Marcos Vinícius Rocha', '99351819019', '(11) 93322-9087', 'marcos.rocha@email.com',    'Av. Paulista, 1500 - Bela Vista, São Paulo/SP',    '2026-05-09 13:30:00'),
('Patrícia Gomes',        '93786579741', '(11) 92211-6645', 'patricia.gomes@email.com',  'Rua Oscar Freire, 300 - Pinheiros, São Paulo/SP',  '2026-05-27 15:10:00'),
('Ricardo Nogueira',      '54323194897', '(11) 91100-8832', 'ricardo.nog@email.com',     'Rua do Gasômetro, 90 - Brás, São Paulo/SP',        '2026-06-15 10:45:00'),
('Sandra Oliveira',       '75749118606', '(19) 98877-4411', 'sandra.oliveira@email.com', 'Rua Barão de Jaguara, 410 - Campinas/SP',           '2026-07-03 08:50:00'),
('Thiago Mendes',         '25276018987', '(11) 97766-2200', 'thiago.mendes@email.com',   'Rua Itapura, 612 - Tatuapé, São Paulo/SP',         '2026-07-22 17:25:00'),
('Valéria Cardoso',       '55597971115', '(11) 96688-1357', 'valeria.cardoso@email.com', 'Av. Aricanduva, 5000 - Aricanduva, São Paulo/SP',  '2026-08-14 12:00:00'),
('Wagner Teixeira',       '47104974601', '(13) 99655-4820', 'wagner.teixeira@email.com', 'Av. Ana Costa, 250 - Santos/SP',                   '2026-09-08 09:35:00');

INSERT INTO destinos (cidade, pais, descricao) VALUES
('Rio de Janeiro',      'Brasil',    'A cidade maravilhosa: Cristo Redentor, Pão de Açúcar, praias de Ipanema e Copacabana e uma vida noturna vibrante.'),
('Gramado',             'Brasil',    'Charme europeu na Serra Gaúcha, com chocolate artesanal, fondue, lagos e o famoso Natal Luz.'),
('Fernando de Noronha', 'Brasil',    'Arquipélago de águas cristalinas, mergulho com tartarugas e algumas das praias mais lindas do mundo.'),
('Lisboa',              'Portugal',  'Ruas históricas, bondes amarelos, pastéis de Belém, fado e passeios para Sintra e Cascais.'),
('Paris',               'França',    'Torre Eiffel, Louvre, passeio de barco no Sena e a gastronomia mais refinada da Europa.'),
('Cancún',              'México',    'Mar do Caribe, resorts all inclusive, ruínas maias e cenotes para explorar.'),
('Buenos Aires',        'Argentina', 'Tango, carnes, vinhos e arquitetura europeia a poucas horas de voo de São Paulo.'),
('Santiago',            'Chile',     'Capital cercada pelos Andes, vinícolas premiadas e acesso fácil às melhores estações de esqui.');

INSERT INTO pacotes (destino_id, titulo, preco, duracao_dias, vagas_total, data_saida, data_retorno, ativo) VALUES
(1, 'Rio Clássico - Cristo e Pão de Açúcar', 2890.00,  6, 20, '2026-12-10', '2026-12-15', 1),
(2, 'Natal Luz em Gramado',                  3450.00,  6, 16, '2026-12-18', '2026-12-23', 1),
(3, 'Noronha Mergulho e Natureza',           6890.00,  7, 12, '2027-02-05', '2027-02-11', 1),
(4, 'Lisboa e Sintra',                       7990.00,  9, 15, '2027-03-12', '2027-03-20', 1),
(5, 'Paris Romântica',                      11900.00,  9, 10, '2027-04-09', '2027-04-17', 1),
(6, 'Cancún All Inclusive',                  8450.00,  8, 18, '2027-01-15', '2027-01-22', 1),
(7, 'Buenos Aires Tango e Vinho',            4290.00,  6, 14, '2027-01-08', '2027-01-13', 1),
(8, 'Santiago e Valle Nevado',               5200.00,  7, 12, '2027-07-10', '2027-07-16', 1),
(1, 'Réveillon no Rio',                      4890.00,  5,  4, '2026-12-29', '2027-01-02', 1),
(2, 'Gramado Serra Gaúcha (encerrado)',      2790.00,  5, 10, '2026-09-04', '2026-09-08', 0);

INSERT INTO reservas (cliente_id, pacote_id, qtd_pessoas, status, observacoes, criado_em) VALUES
( 1, 10, 2, 'confirmada', 'Casal - lua de mel',            '2026-06-12 10:00:00'),
( 2, 10, 3, 'confirmada', NULL,                            '2026-06-20 11:30:00'),
( 3,  1, 2, 'confirmada', NULL,                            '2026-08-03 09:40:00'),
( 4,  2, 4, 'confirmada', 'Família com 2 crianças',        '2026-08-15 15:00:00'),
( 5,  3, 2, 'confirmada', NULL,                            '2026-09-02 14:10:00'),
( 6,  4, 2, 'pendente',   'Aguardando primeiro pagamento', '2026-09-18 16:20:00'),
( 7,  5, 2, 'confirmada', 'Aniversário de casamento',      '2026-09-25 10:15:00'),
( 8,  6, 3, 'confirmada', NULL,                            '2026-10-01 13:00:00'),
( 9,  7, 2, 'confirmada', NULL,                            '2026-10-07 09:00:00'),
(10,  9, 4, 'confirmada', 'Grupo de amigos',               '2026-10-12 17:45:00'),
(11,  8, 2, 'pendente',   NULL,                            '2026-10-20 11:20:00'),
(12,  1, 3, 'cancelada',  'Cliente desistiu da viagem',    '2026-10-22 08:30:00'),
( 1,  6, 2, 'confirmada', NULL,                            '2026-10-28 10:10:00'),
( 3,  7, 2, 'pendente',   NULL,                            '2026-11-02 15:35:00'),
( 5,  2, 2, 'confirmada', NULL,                            '2026-11-05 12:50:00'),
( 2,  4, 1, 'pendente',   'Viagem solo',                   '2026-11-06 18:05:00');

-- valor total = preço do pacote x quantidade de pessoas
UPDATE reservas r JOIN pacotes p ON p.id = r.pacote_id
   SET r.valor_total = p.preco * r.qtd_pessoas;

INSERT INTO pagamentos (reserva_id, valor, data_pagamento, forma, observacao) VALUES
( 1,  5580.00, '2026-06-15', 'pix',            'Pagamento integral'),
( 2,  4185.00, '2026-06-22', 'cartao_credito', 'Parcela 1/2'),
( 2,  4185.00, '2026-07-22', 'cartao_credito', 'Parcela 2/2'),
( 3,  5780.00, '2026-08-05', 'transferencia',  'Pagamento integral'),
( 4,  6900.00, '2026-08-16', 'pix',            'Entrada'),
( 5,  6000.00, '2026-09-05', 'boleto',         'Entrada'),
( 7,  8000.00, '2026-09-28', 'cartao_credito', 'Parcela 1'),
( 7,  8000.00, '2026-10-28', 'cartao_credito', 'Parcela 2'),
( 8, 12675.00, '2026-10-02', 'pix',            'Entrada 50%'),
( 8, 12675.00, '2026-10-20', 'pix',            'Quitação'),
( 9,  3000.00, '2026-10-09', 'pix',            'Sinal'),
(10,  9780.00, '2026-10-14', 'cartao_credito', 'Entrada 50%'),
(13,  5000.00, '2026-10-30', 'pix',            'Sinal'),
(15,  3450.00, '2026-11-06', 'pix',            'Entrada');

-- situação financeira calculada a partir dos pagamentos
UPDATE reservas r SET r.valor_pago = (SELECT COALESCE(SUM(p.valor),0) FROM pagamentos p WHERE p.reserva_id = r.id);
UPDATE reservas SET status_pagamento = CASE
   WHEN valor_pago <= 0 THEN 'pendente'
   WHEN valor_pago >= valor_total THEN 'pago'
   ELSE 'parcial' END;

INSERT INTO historico (usuario_id, usuario_nome, acao, tabela, registro_id, detalhes, criado_em) VALUES
(1, 'Administrador Horizonte',  'criou',    'pacotes',    9,  'Pacote "Réveillon no Rio" cadastrado',      '2026-10-05 09:00:00'),
(2, 'Marina Costa (Atendente)', 'criou',    'reservas',   10, 'Reserva #10 criada (4 pessoas)',            '2026-10-12 17:45:00'),
(2, 'Marina Costa (Atendente)', 'cancelou', 'reservas',   12, 'Reserva #12 cancelada - vagas liberadas',   '2026-10-25 10:20:00'),
(1, 'Administrador Horizonte',  'criou',    'pagamentos', 14, 'Pagamento de R$ 3.450,00 na reserva #15',   '2026-11-06 12:55:00');
